#ifndef _BITMAP2_H_
#define _BITMAP2_H_

#include <Windows.h>
#include <time.h>
#include <math.h>

void RotateBlt(HDC hdc, int dest_x, int dest_y, int dest_width, int dest_height,
	HBITMAP hBit, int source_x, int source_y, int sw, int sh, DWORD dFlag, float angle, COLORREF bkColor, int animation);
float CalcAngle(float px, float py, float px2, float py2);
float GetRadian(float nAngle);
float LengthPts(float x1, float y1, float x2, float y2);

#endif