#ifndef _ARM_H_
#define _ARM_H_

#pragma once
#include "GameObject.h"
#include "Bitmap.h"

class Arm : public GameObject
{
private:
	HWND m_hWnd;
	CBitmap bitmap;
	
	Vector2D mouseTmp;
	POINT mousePoint;
	//�浹�ڽ�
	CollInfo collider;
	bool network;
	Vector2D scroll; //��Ʈ��ũ��� ��ũ��
public:
	float angle;
public:
	Arm();
	Arm(Vector2D initPos, Vector2D initDir, bool _network);
	~Arm();
	void init();
	void Update(float dt);
	void Render(HDC hdc, float dt);
	void Delete();
	CollInfo Collider();
	void setWindowHWND(HWND hWnd){ m_hWnd = hWnd; };
	void ArrowPlayer(Vector2D playerlocate, Vector2D playerPos) { playerlocate.x -= 50; playerlocate.y -= 30; locate = playerlocate;
	playerPos.x -= 50; playerPos.y -= 30; pos = playerPos;};

	//��Ʈ��ũ ����
	void camera(float moving);
};

#endif