#include "GameScene.h"
#include "Bitmap.h"


static int x = 0, y = 0;

GameScene::GameScene()
{
}

void GameScene::create()
{
	Vector2D initPlayerPos(200, 200);
	Vector2D initBosPos(1850, 200);
	Vector2D initPat1Pos(1850, 500);
	Vector2D initPat2Pos(1850, 400);
	Vector2D initPat3Pos(1850, 600);

	Vector2D initPat4Pos(1850, 300); // sinBullet
	Vector2D initPat5Pos(1850, 300); // nwayBullet
	Vector2D initPat6Pos; // rainBullet

	Vector2D dir(1, 0);
	player = new Player(initPlayerPos, dir, ARROW_PLAYER_SPEED , false);
	map = new Map(gamescene);
	boss = new Boss(initBosPos, dir);
	patten1 = new Patten(initPat1Pos, dir, spiralBullet, 7);
	patten2 = new Patten(initPat2Pos, dir, directionalBullet200, 20);
	patten3 = new Patten(initPat3Pos, dir, directionalBullet160, 20);

	patten4 = new Patten(initPat4Pos, dir, sinBullet, 20);
	patten5 = new Patten(initPat5Pos, dir, nwayBullet, 7);
	patten6 = new Patten(initPat6Pos, dir, rainBullet, 7);
}

void GameScene::initialize()
{
	map->init();
	player->init();
	boss->init();
	
	/*patten1->init();
	patten2->init();
	patten3->init();*/
	patten4->init();
	patten5->init();
	patten6->init();

	/*patten1->setPlayerPointer(player);
	patten2->setPlayerPointer(player);
	patten3->setPlayerPointer(player);*/
	patten4->setPlayerPointer(player);
	patten5->setPlayerPointer(player);
	patten6->setPlayerPointer(player);


	player->setCurrentMapSize(map->getBitMapSize());
}

void GameScene::update(float dt)
{
	//coll 
	Coll_Player_Tile(player, map, dt);

	//event
	if (player->Fire()){
		ArcherSkillOne *sk = new ArcherSkillOne(player->getWeaponPos(), player->getWeaponDir());
		sk->init();
		arrow.push_back(*sk);
		delete sk;
	}

	float tmp = player->PlayerEvent(dt);

	//patten1->camera(tmp);
	//patten2->camera(tmp);
	//patten3->camera(tmp);

	patten4->camera(tmp);
	patten5->camera(tmp);
	patten6->camera(tmp);
	map->camera(tmp);
	boss->camera(tmp);

	//object update
	player->Update(dt);
	boss->Update(dt);
	map->Update(dt);

	/*patten1->Update(dt);
	patten2->Update(dt);
	patten3->Update(dt);*/

	patten4->Update(dt);
	patten5->Update(dt);
	patten6->Update(dt);
	//��ų������ ������ ����
	if (!arrow.empty())
		for (auto i = arrow.begin(); i != arrow.end();){
			(*i).camera(tmp);
			(*i).Update(dt);
			//���� - ��ų
			if (CollObejct(boss, &(*i), BOSS_COLL_DISTANCE)){
				boss->hp -= ARROW_DAMAGE;
				arrow.erase(i++);
			}
			else if ((*i).distFirstPos() > REMOVE_SKILL_DIST)
				arrow.erase(i++);
			else
				i++;
		}

	if (GetAsyncKeyState(VK_RETURN) && 0x8000)
	{
		g_framework = CGameFramework::getGameFramework();
		g_framework->getSceneManager()->popScene();
	}
}

void GameScene::render(HDC hdc, float dt)
{
	map->Render(hdc, dt);

	//player�� ī�޶󰡵Ǳ� ���� ������ �ڵ鰪
	player->setWindowHWND(getWindowHWND());
	player->Render(hdc, dt);
	boss->Render(hdc, dt);

	//patten1->Render(hdc, dt);
	//patten2->Render(hdc, dt);
	//patten3->Render(hdc, dt);

	patten4->Render(hdc, dt);
	patten5->Render(hdc, dt);
	patten6->Render(hdc, dt);

	if (!arrow.empty())
		for (auto i = arrow.begin(); i != arrow.end(); i++)
			(*i).Render(hdc, dt);
}

void GameScene::clear()
{
}

void GameScene::destroy()
{
	boss->Delete();
	player->Delete();
	map->Delete();
	/*patten1->Delete();
	patten2->Delete();
	patten3->Delete();*/

	patten4->Delete();
	patten5->Delete();
	patten6->Delete();
	for (auto i = arrow.begin(); i != arrow.end();)
		arrow.erase(i++);
	delete boss;
	delete player;
	delete map;
}