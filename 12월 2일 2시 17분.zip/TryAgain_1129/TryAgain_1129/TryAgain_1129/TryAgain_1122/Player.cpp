#include "Player.h"
#include "WrappedWnd.h"

Player::Player()
{
}
Player::Player(Vector2D initPos, Vector2D initDir,float speed, bool _network)
{
	pos = initPos;
	locate = initPos;
	dir = initDir;
	this->speed = speed;
	hp = 100;
	network = _network;
}
Player::~Player()
{
}

void Player::init()
{
	//player init
	bitmap.init("res/Player.bmp");
	aniInfo[r_idle].image.init("res/player_r_idle.bmp");
	aniInfo[r_idle].aniNum = 1; // 2��
	aniInfo[l_idle].image.init("res/player_r_idle.bmp");
	aniInfo[l_idle].aniNum = 1; // 2��
	aniInfo[r_attact].image.init("res/player_r_idle.bmp");
	aniInfo[r_attact].aniNum = 1; // 2��
	aniInfo[l_attact].image.init("res/player_r_idle.bmp");
	aniInfo[l_attact].aniNum = 1; // 2��
	aniInfo[r_jump].image.init("res/player_r_idle.bmp");
	aniInfo[r_jump].aniNum = 1; // 2��
	aniInfo[l_jump].image.init("res/player_r_idle.bmp");
	aniInfo[l_jump].aniNum = 1; // 2��
	aniInfo[r_fall].image.init("res/player_r_idle.bmp");
	aniInfo[r_fall].aniNum = 1; // 2��
	aniInfo[l_fall].image.init("res/player_r_idle.bmp");
	aniInfo[l_fall].aniNum = 1; // 2��
	aniInfo[r_hit].image.init("res/player_r_idle.bmp");
	aniInfo[r_hit].aniNum = 1; // 2��
	aniInfo[l_hit].image.init("res/player_r_idle.bmp");
	aniInfo[l_hit].aniNum = 1; // 2��
	aniInfo[down].image.init("res/player_r_idle.bmp");
	aniInfo[down].aniNum = 1; // 2��


	this->fGravityreiteration = 0;
	state = r_fall;
	isGround = false;
	collider.type = box; // �浹Ÿ��
	setSize(bitmap);

	animationNum = 0;
	aniTime = 0.0f;
	skillOne_Time = 0.0f;
	skillOne_Ready = false;
	//arm init
	Vector2D armRotate(0,0);
	arm = new Arm(locate, armRotate, network);
	arm->init();
}


void Player::Update(float dt)
{
	//Ŀ�� ��ǥ
	GetCursorPos(&mousePoint);
	ScreenToClient(m_hWnd, (LPPOINT)&mousePoint);

	//player
	//���°� �ش� �����϶� �ش��Լ� ����
	if (state == r_jump || state == l_jump || state == r_fall || state == l_fall)
		Jump(dt);
	else if (this->state == down)
		Down(dt);

	//�ִϸ��̼�
	setAniTime(dt);
	setSkillTime(dt);
	//printf("%d %d\n", state,isGround);

	//arm updates
	ArmUpdate(dt);
}

void Player::ArmUpdate(float dt)
{
	//arm updates
	arm->ArrowPlayer(locate, pos);
	arm->setWindowHWND(m_hWnd);
	arm->Update(dt);
}


void Player::Render(HDC hdc, float dt)
{

	//bitmap.drawRect(hdc, (int)locate.x, (int)locate.y, bitmap.getBitmapInfo().bmWidth, bitmap.getBitmapInfo().bmHeight);
	//bitmap.drawBitmap(hdc, (int)locate.x, (int)locate.y, 0, 0);
	
	//������ ��������� �ִϸ��̼� ��ȣ�� �ǹ� -(���� �Լ����� ��� �ٲ���)
	if (!network)
	aniInfo[state].image.drawBitmap(hdc, (int)locate.x, (int)locate.y,
		aniInfo[state].image.getBitmapInfo().bmWidth / R_IDLE_IMAGE_WIDTH_COUNT, aniInfo[state].image.getBitmapInfo().bmHeight, animationNum);
	else 
		aniInfo[state].image.drawBitmap(hdc, (int)pos.x + (int)scroll.x, (int)pos.y + (int)scroll.y,
		aniInfo[state].image.getBitmapInfo().bmWidth / R_IDLE_IMAGE_WIDTH_COUNT, aniInfo[state].image.getBitmapInfo().bmHeight, animationNum);
	//SetWindowPos();

	arm->Render(hdc,dt);
}


void Player::Delete()
{
	delete(arm);
}

//call by scene
CollInfo Player::Collider()
{
	//���Ͻ�ũ��������
	pos.y = locate.y;
	collider.obejctType = e_player;
	collider.rt.left = (LONG)pos.x;
	collider.rt.right = (LONG)pos.x + bitmap.getBitmapInfo().bmWidth;
	collider.rt.top = (LONG)pos.y;
	collider.rt.bottom = (LONG)pos.y + bitmap.getBitmapInfo().bmHeight;
	collider.center.x = collider.rt.left+(collider.rt.right - collider.rt.left) / 2;
	collider.center.y = collider.rt.top+(collider.rt.bottom - collider.rt.top) / 2;
	return collider;
}

float Player::PlayerEvent(float dt)
{
	float scroll=0;
	//printf("%.2f %.2f \t %.2f %.2f\n", pos.x, pos.x , locate.x , locate.y);

	if ( GetAsyncKeyState( 'D' ) & 0x8000 )
	{
		//�ǳ� ��
		if (pos.x >= curMapSize.x - WINDOW_WIDTH / 2){
			this->locate.x += speed * dt;
			this->pos.x = curMapSize.x + locate.x - WINDOW_WIDTH;
		}
		//ó�� ��
		else if (locate.x < WINDOW_WIDTH / 2){
			this->locate.x += speed * dt;
			this->pos.x = locate.x;
		}
		//��ũ���ʿ�
		else if (locate.x >= WINDOW_WIDTH / 2)	{
			this->locate.x = WINDOW_WIDTH / 2;
			this->pos.x += speed * dt;
			//�ʽ�ũ�Ѱ�����
			
		}
		//state = r_run;
		
	}
	if (GetAsyncKeyState('A') & 0x8000)
	{
		//�ǿ���
		if (pos.x <= WINDOW_WIDTH / 2){
			scroll += (float) (pos.x - locate.x);
			this->locate.x -= speed * dt;
			this->pos.x = locate.x;
		}
		//������
		else if (locate.x > WINDOW_WIDTH / 2){
			
			this->locate.x -= speed * dt;
			this->pos.x = curMapSize.x + locate.x - WINDOW_WIDTH;
		}
		else if (locate.x <= WINDOW_WIDTH / 2){
			this->locate.x = WINDOW_WIDTH / 2;
			this->pos.x -= speed * dt;
			//�ʽ�ũ�Ѱ�����
		}
	}
	if ( GetAsyncKeyState( 'W' ) & 0x8000 )
	{
		if (this->isGround){
			this->fGravityreiteration = ARROW_PLAYER_JUMPPOWER;
			this->state = r_jump;
			this->isGround = false;
		}
	}

	if (GetAsyncKeyState('S') & 0x8000)
	{
		if (this->isGround){
			this->fGravityreiteration = 0;
			this->state = down;
			this->isGround = !isGround;
		}
	}

	//printf("%.2f %.2f\n", locate.x ,  pos.x);

	scroll = (float)locate.x - (float)pos.x;
	return scroll;
}


void Player::Down(float dt)
{
	//�ӽù��� Down �Լ��� �Ҿ���(��������)
	if (locate.y < 650){
		fGravityreiteration += (float)GRAVITY * dt;
		this->locate.y += fGravityreiteration;
	}
	else{
		state = r_idle;
		isGround = true;
	}
}

void Player::Jump(float dt)
{
	//gravity effect
	if( !this->isGround ){
		fGravityreiteration += (float)GRAVITY * dt;
	}
	//jump
	this->locate.y += fGravityreiteration;

	//state check
	if (fGravityreiteration >= 0) this->state = r_fall;
	else this->state = r_jump;
}

//�浹�����Լ�
void Player::collCorrection(int top)
{
	//�������� 
	if (this->locate.y + bitmap.getBitmapInfo().bmHeight >= top){
		this->locate.y = top - bitmap.getBitmapInfo().bmHeight;
		this->isGround = true;
	}
	if (isGround){
		this->state = r_idle;
		this->fGravityreiteration = 0;
	}
}

//��ų�����Լ�
void Player::setSkillTime(float dt)
{
	skillOne_Time += dt;
	if (skillOne_Time > dt * 30)
	{
		//��Ÿ�� ����
		skillOne_Ready = true;
	}
}
bool Player::Fire()
{
	if (GetAsyncKeyState(VK_LBUTTON)){
		if (skillOne_Ready){
			skillOne_Time = 0;
			skillOne_Ready = false;
			return true;
		}
	}
	return false;
}
//////////////

void Player::setAniTime(float dt)
{
	aniTime += dt; 
	if (aniTime > dt * 10) // 10�����Ӵ� 1�� �ٲ�
	{
		animationNum++;
		if (animationNum > aniInfo[state].aniNum) 
			animationNum = 0;
		aniTime = 0.0f;
	}
	//printf("%d\n", animationNum);
}


void Player::FixClientCursor(POINT *p)
{
	p->x -= STARTWINDOW_X;
	p->y -= STARTWINDOW_Y;
}


void Player::camera(float moving)
{
	scroll.x = moving;
}