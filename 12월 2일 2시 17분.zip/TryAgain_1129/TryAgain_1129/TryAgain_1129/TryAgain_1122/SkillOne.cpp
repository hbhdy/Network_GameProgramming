#include "SkillOne.h"

ArcherSkillOne::ArcherSkillOne()
{
}
ArcherSkillOne::ArcherSkillOne(Vector2D initPos, Vector2D initDir)
{
	firstPos = initPos;
	pos = initPos;
	locate.Zero();
	dir = initDir;
	speed = ARROW_SPEED;
	angle = (float)atan2(pos.y - (pos.y + dir.y), pos.x - (pos.x + dir.x));
}
ArcherSkillOne::~ArcherSkillOne()
{
}

void ArcherSkillOne::initPos(bool _network)
{	
	firstPos.x = -100;
	firstPos.y = -100;
	if (_network){
		pos = firstPos;
		dir = firstPos;
		angle = 0;
	}
}

void ArcherSkillOne::init()
{
	bitmap.init("res/arrow1.bmp");
}

void ArcherSkillOne::Update(float dt)
{
	locate = pos + scroll;

	pos.x += dir.x * speed * dt;
	pos.y += dir.y * speed * dt;
}

void ArcherSkillOne::Render(HDC hdc, float dt)
{
	bitmap.drawBitmapRotate(hdc, (int)pos.x + (int)scroll.x, (int)pos.y + (int)scroll.y, 0, 0, 0, angle);
}

void ArcherSkillOne::Delete()
{
}

float ArcherSkillOne::distFirstPos()
{
	return (float)firstPos.Distance(pos);
}

void ArcherSkillOne::camera(float moving)
{
	scroll.x = moving;
}

CollInfo ArcherSkillOne::Collider()
{
	collider.obejctType = e_skill;
	collider.center = pos;
	collider.rt.left = (LONG)pos.x;
	collider.rt.right = (LONG)pos.x + bitmap.getBitmapInfo().bmWidth;
	collider.rt.top = (LONG)pos.y;
	collider.rt.bottom = (LONG)pos.y + bitmap.getBitmapInfo().bmHeight;
	collider.center.x = collider.rt.left + (collider.rt.right - collider.rt.left) / 2;
	collider.center.y = collider.rt.top + (collider.rt.bottom - collider.rt.top) / 2;
	return collider;
}

//------------------------------------------------------------------------------------------------

HealerSkillOne::HealerSkillOne()
{
}
HealerSkillOne::HealerSkillOne(Vector2D initPos, Vector2D initDir)
{
	pos = initPos;
	locate.Zero();
	dir = initDir;
	speed = ARROW_SPEED;
	//angle = 0;
}
HealerSkillOne::~HealerSkillOne()
{
}

void HealerSkillOne::init()
{
	bitmap.init("res/Heal.bmp");
}

void HealerSkillOne::Update(float dt)
{
	locate = pos + scroll;
	//	if (launch == true) {
	locate.x += speed * dt;
	locate.y += speed * dt;
	//	}
}

void HealerSkillOne::Render(HDC hdc, float dt)
{
	bitmap.drawBitmap(hdc, (int)pos.x + (int)scroll.x, (int)pos.y + (int)scroll.y, 0, 0);
}

void HealerSkillOne::Delete()
{
}

void HealerSkillOne::camera(float moving)
{
	scroll.x = moving;
}

CollInfo HealerSkillOne::Collider()
{
	collider.obejctType = e_skill;
	collider.center = pos;
	collider.rt.left = (LONG)pos.x;
	collider.rt.right = (LONG)pos.x + bitmap.getBitmapInfo().bmWidth;
	collider.rt.top = (LONG)pos.y;
	collider.rt.bottom = (LONG)pos.y + bitmap.getBitmapInfo().bmHeight;
	collider.center.x = collider.rt.left + (collider.rt.right - collider.rt.left) / 2;
	collider.center.y = collider.rt.top + (collider.rt.bottom - collider.rt.top) / 2;
	return collider;
}