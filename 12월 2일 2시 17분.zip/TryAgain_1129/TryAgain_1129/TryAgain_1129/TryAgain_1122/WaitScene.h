
#pragma once
#include "GameScene.h"
#include "Scene.h"
#include "set.h"

class WaitScene : public CScene
{
private:
	Player *player;
	Map *map;
	list<ArcherSkillOne> arrow;
	list<Player> otherPlayers;

	ArcherSkillOne otherArrow[MAX_CLIENT][MAX_ARROW_SIZE];
public:

	WaitScene();
	~WaitScene(){};

	void					create();

	void					initialize();

	void					update(float dt);
	void					render(HDC hdc, float dt);

	void					clear();

	void					destroy();

public:



};
