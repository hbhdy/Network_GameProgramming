
#pragma once

using namespace std;


//dest , source Collider�Լ��� ���� ��ü
template<typename Dest, typename Source>
bool CollObejct(Dest *dest, Source *src , int dist)
{
	//�浹�˻�
	if (dest->Collider().center.Distance(src->Collider().center) < dist){
		//printf("%d dtCenter(%.1f %.1f)\tsrcCenter(%.1f %.1f)\n", dest->hp, dest->Collider().center.x, dest->Collider().center.y,
		//	src->Collider().center.x, src->Collider().center);
		return true;
	}
	return false;
}
