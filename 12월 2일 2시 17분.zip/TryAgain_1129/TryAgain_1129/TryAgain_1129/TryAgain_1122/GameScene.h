
#pragma once
#include "Scene.h"
#include "set.h"

class GameScene : public CScene
{
private:
	Player *player;
	Map *map;
	Boss *boss;
	Patten *patten1, *patten2, *patten3, *patten4, *patten5, *patten6;
	list<ArcherSkillOne> arrow;
public:

	GameScene();
	~GameScene(){};

	void					create();

	void					initialize();

	void					update(float dt);
	void					render(HDC hdc, float dt);

	void					clear();

	void					destroy();

public:



};
