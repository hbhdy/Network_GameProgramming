#include "Arm.h"

Arm::Arm()
{
}
Arm::Arm(Vector2D initPos, Vector2D initDir, bool _network)
{
	pos = initPos;
	locate = initPos;
	dir = initDir;
	angle = 0;
	network = _network;
}
Arm::~Arm()
{
}

void Arm::init()
{
	bitmap.init("res/arm_arrow.bmp");
	collider.type = box;
}


void Arm::Update(float dt)
{
	//Ŀ�� ��ǥ
	if (!network){
		GetCursorPos(&mousePoint);
		ScreenToClient(m_hWnd, (LPPOINT)&mousePoint);

		mouseTmp.x = mousePoint.x;
		mouseTmp.y = mousePoint.y;
		dir = Vec2DNormalize(mouseTmp - locate);
		angle = (float)atan2(locate.y - (mouseTmp.y), locate.x - (mouseTmp.x));
	}
}


void Arm::Render(HDC hdc, float dt)
{
	if (!network)
		bitmap.drawBitmapRotate(hdc, (int)locate.x, (int)locate.y, 0, 0, 0, angle);
	else 
		bitmap.drawBitmapRotate(hdc, (int)pos.x + (int)scroll.x, (int)pos.y + (int)scroll.y, 0, 0, 0, angle);
}

CollInfo Arm::Collider()
{
	collider.rt.left = (LONG)locate.x;
	collider.rt.right = (LONG)(locate.x + bitmap.getBitmapInfo().bmWidth);
	collider.rt.top = (LONG)locate.y;
	collider.rt.bottom = (LONG)(locate.x + bitmap.getBitmapInfo().bmHeight);
	return collider;
}

void Arm::Delete()
{

}

void Arm::camera(float moving)
{
	scroll.x = moving;
}