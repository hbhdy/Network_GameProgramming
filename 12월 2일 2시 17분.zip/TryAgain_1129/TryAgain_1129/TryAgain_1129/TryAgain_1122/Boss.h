#ifndef _BOSS_H_
#define _BOSS_H_

#pragma once
#include "GameObject.h"
#include "Bitmap.h"

class Boss : public GameObject
{
private:
	//�̹���
	CBitmap bitmap;

	int state;
	Vector2D scroll;
	CollInfo collider;

public:
	Boss();
	Boss(Vector2D initPos, Vector2D initDir);
	~Boss();
	void init();
	void Update(float dt);
	void Render(HDC hdc, float dt);
	void Delete();
	void camera(float moving);
	CollInfo Collider();
};

#endif