#pragma once
#include <list>
#include "Vector2D.h"

//������ (�ʿ���)
enum {
	waitscene = 0,
	gamescene
};

//�ݶ��̴� ���� (�����Ⱦ�)
enum {
	box = 0,
	circle
};

//�ݶ��̴� ����
enum {
	e_player = 0,
	e_boss,
	e_barrage,
	e_skill
};

struct CollInfo{
	int type;
	int obejctType;
	//type rect
	RECT rt;
	//type circle
	Vector2D center;
	int radius;
};

struct ArmInfo {
	Vector2D pos;
	float angle;
};

struct PlayerInfo {
	//������ǥ
	Vector2D pos;
	ArmInfo arm;
};

struct ArcherSkillOneInfo {
	Vector2D pos;
	float angle;
};

struct BossInfo {
	Vector2D pos;
};

//Collider�Լ��� ���� ��ü
template<typename Dest, typename Source>
bool CollObejct(Dest *dest, Source *src, int dist)
{
	//�浹�˻�
	if (dest->Collider().center.Distance(src->Collider().center) < dist){
		//printf("%d dtCenter(%.1f %.1f)\tsrcCenter(%.1f %.1f)\n", dest->hp, dest->Collider().center.x, dest->Collider().center.y,
			//src->Collider().center.x, src->Collider().center);
		return true;
	}
	return false;
}
