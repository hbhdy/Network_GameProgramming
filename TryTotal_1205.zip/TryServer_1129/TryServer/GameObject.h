#ifndef _GAMEOBJECT_H_
#define _GAMEOBJECT_H_
#pragma once

#include <stdio.h>
#include "Vector2D.h"
#include "Bitmap.h"
#include <list>
#include "Define.h"
#include "GameObejects.h"

using namespace std;

//������ (�ʿ���)
enum {
	waitscene = 0,
	gamescene
};

//�ݶ��̴� ���� (�����Ⱦ�)
enum {
	box = 0,
	circle
};

//�ݶ��̴� ����
enum {
	e_player = 0,
	e_boss,
	e_barrage,
	e_skill
};
enum {
	spiralBullet = 0, hurricaneBullet,
	directionalBullet200, directionalBullet160,
	powerBullet
};
struct CollInfo{
	int type;
	int obejctType;
	//type rect
	RECT rt;
	//type circle
	Vector2D center;
	int radius;
};

struct ArmInfo {
	Vector2D pos;
	float angle;
};

struct PlayerInfo {
	//������ǥ
	Vector2D pos;
	Vector2D bitmapSize;
	ArmInfo arm;
	CollInfo collider;
	int hp;

	CollInfo Collider()
	{
		collider.obejctType = e_skill;
		collider.center = pos;
		collider.rt.left = (LONG)pos.x;
		collider.rt.right = (LONG)pos.x + bitmapSize.x;
		collider.rt.top = (LONG)pos.y;
		collider.rt.bottom = (LONG)pos.y + bitmapSize.y;
		collider.center.x = collider.rt.left + (collider.rt.right - collider.rt.left) / 2;
		collider.center.y = collider.rt.top + (collider.rt.bottom - collider.rt.top) / 2;
		return collider;
	}
};

//���� �ϳ��� �Ҹ� �ϳ���� ���� ����
struct PattenInfo {
	Vector2D pos;
	Vector2D bitmapSize;
	CollInfo collider;
	int state;
	int demage;
	bool isColl;
};

struct ArcherSkillOneInfo {
	Vector2D pos;
	Vector2D bitmapSize;//x = witdh //y = height 
	float angle;
	CollInfo collider;
	int demage;
	bool isColl;
	CollInfo Collider()
	{
		collider.obejctType = e_skill;
		collider.center = pos;
		collider.rt.left = (LONG)pos.x;
		collider.rt.right = (LONG)pos.x + bitmapSize.x;
		collider.rt.top = (LONG)pos.y;
		collider.rt.bottom = (LONG)pos.y + bitmapSize.y;
		collider.center.x = collider.rt.left + (collider.rt.right - collider.rt.left) / 2;
		collider.center.y = collider.rt.top + (collider.rt.bottom - collider.rt.top) / 2;
		return collider;
	}
};

struct BossInfo {
	Vector2D pos;
	Vector2D bitmapSize;//x = witdh //y = height 
	int hp;
	CollInfo collider;

	CollInfo Collider()
	{
		collider.obejctType = e_boss;
		collider.center = pos;
		collider.rt.left = (LONG)pos.x;
		collider.rt.right = (LONG)pos.x + bitmapSize.x;
		collider.rt.top = (LONG)pos.y;
		collider.rt.bottom = (LONG)pos.y + bitmapSize.y;
		collider.center.x = collider.rt.left + (collider.rt.right - collider.rt.left) / 2;
		collider.center.y = collider.rt.top + (collider.rt.bottom - collider.rt.top) / 2;
		return collider;
	}
};

class GameObject 
{
protected:

public:
	//�����ǥ
	Vector2D locate;
	//����
	Vector2D dir;
	//������ǥ
	Vector2D pos;
	//�ӵ�
	float speed;
	//hp
	int hp;

	GameObject() ;
	~GameObject() ;

	virtual void init() = 0;
	virtual	void Update(float dt) = 0;
	virtual void Render(HDC hdc, float dt) = 0;
	virtual void Delete() = 0;
};

#endif