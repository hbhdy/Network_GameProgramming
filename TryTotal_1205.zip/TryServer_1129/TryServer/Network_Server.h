﻿#pragma once
#pragma comment(lib, "ws2_32")
#define _WINSOCK_DEPRECATED_NO_WARNINGS
#include <winsock2.h>
#include <stdlib.h>
#include <atlstr.h> // cstring
#include <Windows.h>
#include <stdio.h>
#include "GameObejects.h"
#include <queue>
#include "Define.h"
#include "Patten.h"

using namespace std;



struct ClientInfo{
	//BossInfo boss;
	PlayerInfo player[MAX_CLIENT]; //플레이어의 정보
	int playerSize;
	ArcherSkillOneInfo arrow[MAX_CLIENT][MAX_ARROW_SIZE];
	int arrowSize[MAX_CLIENT];

	BossInfo boss;

	PattenInfo patten[MAX_PATTEN][MAX_BULLET];
	int pattenSize[MAX_PATTEN];

	int myClientValue; //자신이 몇번째 클라이언트인가..
	int nowClient;
	int maxClient;
	int scene; //무슨 씬인가
};

// 클라이언트에 처음에 보낼 맵의 정보를 담는 구조체
struct mapInfo {
	int  **first_mapInfo;
	int  **second_mapInfo;
};

// 소켓 함수 오류 출력 후 종료
void err_quit(char *msg) {
	LPVOID lpMsgBuf;
	FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		NULL, WSAGetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR)&lpMsgBuf, 0, NULL);
	MessageBox(NULL, (LPCTSTR)lpMsgBuf, msg, MB_ICONERROR);
	LocalFree(lpMsgBuf);
	exit(1);
}

// 소켓 함수 오류 출력
void err_display(char *msg) {
	LPVOID lpMsgBuf;
	FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		NULL, WSAGetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR)&lpMsgBuf, 0, NULL);
	printf("[%s] %s", msg, (char *)lpMsgBuf);
	LocalFree(lpMsgBuf);
}

// 사용자 정의 데이터 수신 함수
int recvn(SOCKET s, char *buf, int len, int flags) {
	int received;
	char *ptr = buf;
	int left = len;

	while (left > 0) {
		received = recv(s, ptr, left, flags);
		if (received == SOCKET_ERROR)
			return SOCKET_ERROR;
		else if (received == 0)
			break;
		left -= received;
		ptr += received;
	}

	return (len - left);
}
