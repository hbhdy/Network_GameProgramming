#ifndef _SKILLONE_H_
#define _SKILLONE_H_

#pragma once
#include "GameObject.h"
#include "Bitmap.h"
//#include <vector>

// ���� 1�� ��ų
class ArcherSkillOne : public GameObject
{
private:
	// ��ų�� ������
	int impact;  // ����
	HWND m_hWnd;

	bool network;
	//�߻� ��ġ
	Vector2D firstPos;
	//�̹���
	CBitmap bitmap;
	Vector2D bitmapSize;
	Vector2D scroll;
	CollInfo collider;
public:
	// �߻�
	float angle;
	bool launch;

public:
	ArcherSkillOne();
	ArcherSkillOne(Vector2D initPos, Vector2D initDir);
	~ArcherSkillOne();
	void initPos(bool _network);
	void init();
	void Update(float dt);
	void Render(HDC hdc, float dt);
	void Delete();
	bool getlaunch() { return launch; }
	Vector2D getBitmapSize(){ bitmapSize.x = bitmap.getBitmapInfo().bmWidth; bitmapSize.y = bitmap.getBitmapInfo().bmHeight; return bitmapSize; }
	void setlaunch(bool _launch) { launch = _launch; }

	float distFirstPos();
	void camera(float moving);
	CollInfo Collider();
};

// ���� 1�� ��ų
class HealerSkillOne : public GameObject
{
private:
	// ��ų�� ������, ����
	int impact;  // ����

	HWND m_hWnd;

	//�̹���
	CBitmap bitmap;
	Vector2D scroll;
	CollInfo collider;
public:
	// �߻�
	bool launch;

public:
	HealerSkillOne();
	HealerSkillOne(Vector2D initPos, Vector2D initDir);
	~HealerSkillOne();
	void init();
	void Update(float dt);
	void Render(HDC hdc, float dt);
	void Delete();
	bool getlaunch() { return launch; }
	void setlaunch(bool _launch) { launch = _launch; }
	void camera(float moving);
	CollInfo Collider();
	//void SkillPlayer(Vector2D playerPos) { playerPos.x -= 15;  locate = playerPos; };
};

#endif