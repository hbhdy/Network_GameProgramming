#pragma once
//#include <winsock2.h>
//#include <windows.h>
//#include <cstdio>
//#include <queue>
//#include "Player.h"
//#include "SkillOne.h"
//#include "Boss.h"
#pragma comment(lib, "ws2_32")
#include <winsock2.h>
#include <stdio.h>
#include "NetworkInfo.h"

#define SERVERIP "127.0.0.1"
#define SERVERPORT 9000

using namespace std;

class Network
{
	int retval;
	int len;
	int GetSize;
	//treatedByServerInfo *totalServerInfo;
	SOCKET sock;
	char *tempBuffer;
public:
	//ClientInfo clientInfo;//Ŭ�󰡰�������
	ClientInfo *tbServerInfo;
public:
	//-----------------------------------------------------------
	
	//-----------------------------------------------------------
	Network();
	~Network();
	void err_quit(char *msg);
	void err_display(char *msg);
	int recvn(SOCKET s, char *buf, int len, int flags);
	bool init_sock();

	SOCKET getSocket(){ return sock; }
//	void setClientInfo(ClientInfo ci){ clientInfo = ci; };
	void init();
	void recvFromServer(SOCKET s, int flags);
	bool recvFromServer(SOCKET s, ClientInfo tbServerInfo, int len, int flags);
	bool sendToServer(SOCKET s, ClientInfo clientInfo, int flag);

};