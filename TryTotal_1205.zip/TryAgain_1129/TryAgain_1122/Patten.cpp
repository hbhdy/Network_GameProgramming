#include "Patten.h"

Patten::Patten()
{
}

Patten::Patten(Vector2D initPos, Vector2D initDir,int _state , int _frameDelay)
{
	//�÷��̾� �� ��ü�� pos�� ������ǥ, locate�� ȭ����ǥ..
	pos = initPos;
	locate.Zero();
	dir = initDir;
	state = _state;
	frameDelay = _frameDelay;
}

Patten::~Patten()
{
}

void Patten::init()
{
	bitmap.init("res/skill1.bmp");
	delayTime = 0;
	isCreateBullet = false;
}

void Patten::Update(float dt)
{
	setBulletTime(dt);
	if (isCreateBullet)	{
		Bullet *bl = new Bullet(pos, state);
		bl->init(bitmap);
		bullets.push_back(*bl);
		isCreateBullet = false;
		delete bl;
	}

	//��������
	for (auto i = bullets.begin(); i != bullets.end();){
		(*i).Update(dt);

		//�÷��̾�� �浹ó��
		if (CollObejct(pPlayer, &(*i), PLAYER_COLL_DISTANCE)){
			bullets.erase(i++);
		}
		//printf("%.2f\n", (*i).pos.x + (*i).scroll.x);
		//�����Ÿ� �ʰ��� or �浹��
		else if ( (pos.Distance((*i).pos) > REMOVE_SKILL_DIST ))
			bullets.erase(i++);
		else
			i++;
	}
}

void Patten::Render(HDC hdc, float dt)
{
	for (auto i = bullets.begin(); i != bullets.end(); i++)
		(*i).Render(hdc,dt);
}

void Patten::Delete()
{
	for (auto i = bullets.begin(); i != bullets.end(); i++)
		(*i).Delete();
	for (auto i = bullets.begin(); i != bullets.end();)
		bullets.erase(i++);
}

void Patten::camera(float moving)
{
	for (auto i = bullets.begin(); i != bullets.end(); i++)
		(*i).camera(moving);
}

void Patten::setBulletTime(float dt)
{
	delayTime += dt;
	if (delayTime > dt * frameDelay) // 10�����Ӵ� 1�� �ٲ�
	{
		if (!isCreateBullet) {
			isCreateBullet = true;
		}
		delayTime = 0.0f;
	}
}