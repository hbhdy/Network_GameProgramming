#include "StartScene.h"
#include "Bitmap.h"

static int x = 0, y = 0;
static char ipData[15];
static char portData[5];
static bool gameStart;
Network *network;

HINSTANCE hInstance;

BOOL CALLBACK DlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);

StartScene::StartScene()
{
}

void StartScene::create()
{
	bitmap.init("res/StartScene.bmp");
	gameStart = false;
	network = new Network();
}

void StartScene::initialize()
{	
	network->init();
}

void StartScene::update(float dt)
{
	//���ӽ��� 370 454  653 535   ( L T R B )
	//���� ���� 370 623  653 700
	GetCursorPos(&mPos);
	ScreenToClient(m_hWnd, (LPPOINT)&mPos);

	if (GetAsyncKeyState(VK_LBUTTON) && 0x8000 ) {
		if (mPos.x > 370 && mPos.y > 454 && mPos.x <= 653 && mPos.y <= 535 && gameStart==false) {
			DialogBox(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, DlgProc);
			printf("�Է��� IP �ּ� : %s  \n�Է��� PORT ��ȣ : %s \n", ipData, portData);
		}
	}
	if (GetAsyncKeyState(VK_LBUTTON) && 0x8000) {
		if (mPos.x > 370 && mPos.y > 623 && mPos.x <= 653 && mPos.y <= 700 ) {
			exit(1);
		}
	}
	if (gameStart == true) {
		//���Ῡ��
		
		if (network->init_sock()){
			//network->tbServerInfo->scene = start;
			//network->setClientInfo(ci);
			network->sendToServer(network->getSocket(), *network->tbServerInfo, 0); //�����ͺ�����
			network->recvFromServer(network->getSocket(), 0); //�ޱ�
			
			//network->tbServerInfo->arrowSize[network->tbServerInfo->myClientValue] = 0;
			printf("\n����Ŭ���̾�Ʈ ���� = %d\n", network->tbServerInfo->myClientValue);
			g_framework = CGameFramework::getGameFramework();
			g_framework->getSceneManager()->registerScene(new WaitScene);
			g_framework->getSceneManager()->reservedScene();
		}
		gameStart = false;
	}
}

void StartScene::render(HDC hdc, float dt)
{
	bitmap.drawBitmap(hdc, 0, 0, 0, 0);
}

void StartScene::clear()
{
}

void StartScene::destroy()
{
}

void StartScene::FixClientCursor(POINT *p)
{
	p->x -= STARTWINDOW_X;
	p->y -= STARTWINDOW_Y;
}

BOOL CALLBACK DlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	char ip[15];
	char port[5];
	switch (uMsg) {
	case WM_COMMAND:
		switch (LOWORD(wParam)) {
		case IDOK:
			GetDlgItemText(hDlg, IDC_EDIT1, ip,15);
			GetDlgItemText(hDlg, IDC_EDIT2, port, 5);
			strcpy(ipData, ip);
			strcpy(portData, port);
			gameStart = true;
			
			EndDialog(hDlg, IDOK);
			return TRUE;

		case IDCANCEL:
			EndDialog(hDlg, IDCANCEL);
		}
		return FALSE;
	}
	return FALSE;
}
