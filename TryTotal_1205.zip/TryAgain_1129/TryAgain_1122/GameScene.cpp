#include "GameScene.h"
#include "Bitmap.h"


static int x = 0, y = 0;
extern Network *network;

GameScene::GameScene()
{
}

void GameScene::create()
{
	Vector2D initPlayerPos(200, 200);
	Vector2D initBosPos(1850, 200);
	Vector2D initPat1Pos(1850, 500);
	Vector2D initPat2Pos(1850, 400);
	Vector2D initPat3Pos(1850, 600);
	Vector2D dir(1, 0);
	player = new Player(initPlayerPos, dir, ARROW_PLAYER_SPEED , false);
	map = new Map(gamescene);
	boss = new Boss(initBosPos, dir);


	patten1 = new Patten(initPat1Pos, dir, spiralBullet, 7);


	for (int i = 0; i < MAX_PLAYER; i++)
		otherPlayers[i] = new Player(initPlayerPos, dir, ARROW_PLAYER_SPEED, true);
}

void GameScene::initialize()
{
	map->init();
	player->init();
	boss->init();

	//���� 1 ���ҽ� �θ���
	patten1->init();

	for (int i = 0; i < MAX_PLAYER; i++)
		otherPlayers[i]->init();
	for (int i = 0; i < MAX_CLIENT; i++)
		for (int j = 0; j < MAX_ARROW_SIZE; j++){
			otherArrow[i][j].init();
			otherArrow[i][j].initPos(true);
		}
	for (int i = 0; i < MAX_PATTEN; i++)
		for (int j = 0; j < MAX_BULLET; j++){
			patten1_Info[i][j].init(patten1->getBitmap());
		}

	player->setCurrentMapSize(map->getBitMapSize());
}

void GameScene::update(float dt)
{
	//coll 
	Coll_Player_Tile(player, map, dt);

	//event
	if (player->Fire()){
		ArcherSkillOne *sk = new ArcherSkillOne(player->getWeaponPos(), player->getWeaponDir());
		sk->init();
		arrow.push_back(*sk);
		delete sk;
	}

	float tmp = player->PlayerEvent(dt);

	map->camera(tmp);

	//object update
	player->Update(dt);
	map->Update(dt);

	//��ų����
	int arrowCount = 0;
	if (!arrow.empty())
		for (auto i = arrow.begin(); i != arrow.end();){
			//(*i).camera(tmp);
			(*i).Update(dt);
			//���� - ��ų
			if (network->tbServerInfo->arrow[network->tbServerInfo->myClientValue][arrowCount].isColl == true ){ //�浹������
				arrow.erase(i++);
				arrowCount++;
			}
			else if ((*i).distFirstPos() > REMOVE_SKILL_DIST){
				arrow.erase(i++);
				arrowCount++;
			}
			else{
				i++;
				arrowCount++;
			}
		}

	//������
	network->tbServerInfo->scene = game;
	//�÷��̾� ����
	network->tbServerInfo->player[network->tbServerInfo->myClientValue].bitmapSize = player->getBitmapSize();
	network->tbServerInfo->player[network->tbServerInfo->myClientValue].pos = player->pos;
	network->tbServerInfo->player[network->tbServerInfo->myClientValue].arm.pos = player->getArm()->pos;
	network->tbServerInfo->player[network->tbServerInfo->myClientValue].arm.angle = player->getArm()->angle;
	//ȭ�� ����
	network->tbServerInfo->arrowSize[network->tbServerInfo->myClientValue] = arrow.size();
	arrowCount = 0;
	for (auto i = arrow.begin(); i != arrow.end(); i++){
		network->tbServerInfo->arrow[network->tbServerInfo->myClientValue][arrowCount].bitmapSize = (*i).getBitmapSize();
		network->tbServerInfo->arrow[network->tbServerInfo->myClientValue][arrowCount].pos = (*i).pos;
		network->tbServerInfo->arrow[network->tbServerInfo->myClientValue][arrowCount].angle = (*i).angle;
		network->tbServerInfo->arrow[network->tbServerInfo->myClientValue][arrowCount].demage = ARROW_DAMAGE;
		arrowCount++;
	}
	//���� ����
	network->tbServerInfo->boss.bitmapSize = boss->getBitmapSize();

	//send //recv
	if (network->sendToServer(network->getSocket(), *network->tbServerInfo, 0)); //�����ͺ�����
	network->recvFromServer(network->getSocket(), 0); //�ޱ�


	//������ó��

	//update network objects
	boss->camera(tmp);
	boss->hp = network->tbServerInfo->boss.hp;
	boss->pos = network->tbServerInfo->boss.pos;

		//����
	for (int i = 0; i < MAX_PATTEN; i++){
		for (int j = 0; j < network->tbServerInfo->pattenSize[i]; j++){
			patten1_Info[i][j].pos = network->tbServerInfo->patten[i][j].pos;
			patten1_Info[i][j].camera(tmp);
		}
	}
		//�÷��̾��
	if (1 < network->tbServerInfo->playerSize){
		for (int i = 0; i < network->tbServerInfo->playerSize; i++){
			//�������� �ڽ��̸� �ƿ� ���簡 �ڽ��̸�++;
			if (network->tbServerInfo->playerSize - 1 == i) break;
			else if (network->tbServerInfo->myClientValue == i)i++;
			//skip to My client player infomation 
			otherPlayers[i]->camera(tmp);
			otherPlayers[i]->pos = network->tbServerInfo->player[i].pos;
			//arm(weapon) network
			otherPlayers[i]->getArm()->angle = network->tbServerInfo->player[i].arm.angle;
			otherPlayers[i]->getArm()->ArrowPlayer(otherPlayers[i]->locate, otherPlayers[i]->pos);
			otherPlayers[i]->getArm()->camera(tmp);
		}
	}
		//ȭ���
	for (int cl = 0; cl < network->tbServerInfo->nowClient; cl++){ //Ŭ���̾�Ʈ����
		for (int i = 0; i < network->tbServerInfo->arrowSize[cl]; i++){ //Ŭ���ַο찹��
			otherArrow[cl][i].initPos(true);
			otherArrow[cl][i].pos = network->tbServerInfo->arrow[cl][i].pos;
			otherArrow[cl][i].angle = network->tbServerInfo->arrow[cl][i].angle;
			otherArrow[cl][i].camera(tmp);
		}
	}

	if (GetAsyncKeyState('R') && 0x8000)
	{
		g_framework = CGameFramework::getGameFramework();
		g_framework->getSceneManager()->popScene();
	}
}

void GameScene::render(HDC hdc, float dt)
{
	map->Render(hdc, dt);

	if (1 < network->tbServerInfo->playerSize)
		for (int i = 0; i < network->tbServerInfo->playerSize; i++){
			if (network->tbServerInfo->playerSize - 1 == i) break;
			else if (network->tbServerInfo->myClientValue == i)i++;
			otherPlayers[i]->Render(hdc, dt);
		}

	//player�� ī�޶󰡵Ǳ� ���� ������ �ڵ鰪
	player->setWindowHWND(getWindowHWND());
	player->Render(hdc, dt);
	boss->Render(hdc, dt);

	for (int i = 0; i < MAX_PATTEN; i++){ 
		for (int j = 0; j < network->tbServerInfo->pattenSize[i]; j++){
			patten1_Info[i][j].Render(hdc, dt);
		}
	}

	for (int cl = 0; cl < network->tbServerInfo->nowClient; cl++){
		for (int i = 0; i < network->tbServerInfo->arrowSize[cl]; i++){
			otherArrow[cl][i].Render(hdc, dt);
		}
	}
}

void GameScene::clear()
{
}

void GameScene::destroy()
{
	boss->Delete();
	player->Delete();
	map->Delete();
	patten1->Delete();
	
	for (auto i = arrow.begin(); i != arrow.end();)
		arrow.erase(i++);

	for (int i = 0; i < MAX_PLAYER; i++)
		otherPlayers[i]->Delete();

	for (int i = 0; i < MAX_PLAYER; i++)
		delete otherPlayers[i];

	delete boss;
	delete player;
	delete map;
	delete patten1;
}