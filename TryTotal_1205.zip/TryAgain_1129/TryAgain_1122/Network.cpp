#include "Network.h"

Network::Network(){ tempBuffer = (char*)malloc(sizeof(char) * 1024); }
Network::~Network() { free(tempBuffer); free(tbServerInfo); }

// ���� �Լ� ���� ��� �� ����
void Network::err_quit(char *msg) {
	LPVOID lpMsgBuf;
	FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		NULL, WSAGetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR)&lpMsgBuf, 0, NULL);
	MessageBox(NULL, (LPCTSTR)lpMsgBuf, msg, MB_ICONERROR);
	LocalFree(lpMsgBuf);
}

// ���� �Լ� ���� ���
void Network::err_display(char *msg) {
	LPVOID lpMsgBuf;
	FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		NULL, WSAGetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR)&lpMsgBuf, 0, NULL);
	printf("[%s] %s", msg, (char *)lpMsgBuf);
	LocalFree(lpMsgBuf);
}	

int Network::recvn(SOCKET s, char *buf, int len, int flags) {
	int received;
	char *ptr = buf;
	int left = len;

	while (left > 0) {
		received = recv(s, ptr, left, flags);
		if (received == SOCKET_ERROR)
			return SOCKET_ERROR;
		else if (received == 0)
			break;
		left -= received;
		ptr += received;	
	}

	return (len - left);
}

void Network::init() 
{
	tbServerInfo = (ClientInfo*)malloc(sizeof(ClientInfo));
	tbServerInfo->scene = start;
	tbServerInfo->maxClient = 4;
}

bool Network::init_sock() {
	int retval;
	// ���� �ʱ�ȭ
	WSADATA wsa;
	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
	}
	// socket()
	sock = socket(AF_INET, SOCK_STREAM, 0);
	if (sock == INVALID_SOCKET) {
		err_display("connect()");
		return false;
	}
	int opt = 1;
	setsockopt(sock, IPPROTO_TCP, TCP_NODELAY, (const char*)&opt, sizeof(opt));

	// connect()
	SOCKADDR_IN serveraddr;
	ZeroMemory(&serveraddr, sizeof(serveraddr));
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_addr.s_addr = inet_addr(SERVERIP);
	serveraddr.sin_port = htons(SERVERPORT);
	retval = connect(sock, (SOCKADDR *)&serveraddr, sizeof(serveraddr));

	if (retval == SOCKET_ERROR) {
		err_display("connect()");
		return false;
	}

	printf("[�˸�] %s:%d ���������� ���� �Ǿ����ϴ�..!\n", SERVERIP, SERVERPORT);
	return true;
}

// ������ �����͸� ������.
bool Network::sendToServer(SOCKET s, ClientInfo clientInfo, int flag) {
	len = sizeof(clientInfo);
	retval = send(s, (char *)&len, sizeof(int), 0);
	if (retval == SOCKET_ERROR) {
		err_display("send()");
		return false;
	}

	// ������ ������( ����ü �����͸� ������. )
	retval = send(s, (char*)&clientInfo, sizeof(ClientInfo), 0);
	if (retval == SOCKET_ERROR) {
		err_display("send()");
		return false;
	}

	return true;
}

// �������� �����͸� �޴´�.
void Network::recvFromServer(SOCKET s, int flags) {
	len = 0;
	GetSize = 0;
	retval = recv(s, (char *)&len, sizeof(int), 0); // ������ �ޱ�(���� ����)
	if (retval == SOCKET_ERROR) {
		err_display("recv()");
	}
	else if (retval == 0) {
	}

	//retval = recv(s, (char*)&tbServerInfo, len, 0);
	tempBuffer = (char*)realloc(tempBuffer, sizeof(char)*len + 1);
	GetSize = recvn(s, tempBuffer, len, 0);

	// �ʱ�ȭ �� �����Ͱ� ����
	tempBuffer[GetSize] = '\0';
	tbServerInfo = (ClientInfo*)tempBuffer;
	
}
