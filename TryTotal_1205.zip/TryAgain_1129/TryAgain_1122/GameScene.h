
#pragma once
#include "Scene.h"
#include "set.h"

class GameScene : public CScene
{
private:
	Player *player;
	Map *map;
	Boss *boss;
	Patten *patten1; //, *patten2, *patten3;
	list<ArcherSkillOne> arrow;

	
	//network
	list<Bullet> bl;
	Player *otherPlayers[MAX_PLAYER];
	Bullet patten1_Info[MAX_PATTEN][MAX_BULLET];

	ArcherSkillOne otherArrow[MAX_PLAYER][MAX_ARROW_SIZE];

public:

	GameScene();
	~GameScene(){};

	void					create();

	void					initialize();

	void					update(float dt);
	void					render(HDC hdc, float dt);

	void					clear();

	void					destroy();

public:



};
