#include "Map.h"
#include "Bitmap.h"

Map::Map()
{
	locate.Zero();
	dir.Zero();
}
Map::~Map()
{
}

void Map::init()
{
	scroll.Zero();
	if (mapValue == gamescene){
		bitmap.init("res/gameMap.bmp");
		LoadTiles(gamescene);
	}
	else if (mapValue == waitscene){
		bitmap.init("res/waitMap.bmp");
		LoadTiles(waitscene);
	}
	
	
}


void Map::Update(float dt)
{
	
}


void Map::Render(HDC hdc, float dt)
{
	bitmap.drawBitmapNotLimpid(hdc, (int)scroll.x, (int)scroll.y, WINDOW_WIDTH - (int)scroll.x, WINDOW_HEIGHT - (int)scroll.y);

	for (auto i = mapTilesList.begin(); i != mapTilesList.end(); i++) {
		if (0 - 32 < (*i).getPosX() + (int)scroll.x && WINDOW_WIDTH + 32 > (*i).getPosX() + (int)scroll.x){
			(*i).getBitmap().drawBitmapNotLimpid(hdc, (*i).getPosX() + (int)scroll.x, (*i).getPosY(), (*i).getSizeX(), (*i).getSizeY());
			//(*i).getBitmap().drawRect(hdc, (*i).getPosX() + scroll.x, (*i).getPosY(), (*i).getSize(), (*i).getSize() );
		}
	}
}

void Map::Delete()
{

}

list<Tile> Map::ColliderList()
{
	return mapTilesList;
}

Vector2D Map::getBitMapSize()
{
	Vector2D size;
	size.x = bitmap.getBitmapInfo().bmWidth;
	size.y = bitmap.getBitmapInfo().bmHeight;
	return size;
}

void Map::LoadTiles(int _mapValue)
{
	int tmpx, tmpy;
	int _count;
	FILE* fp;
	while (!mapTilesList.empty())
		mapTilesList.pop_back();


	if (_mapValue == gamescene)
		fp = fopen("tilemap/GameMap.txt", "rb");
	else if (_mapValue == waitscene)
		fp = fopen("tilemap/WaitMap.txt", "rb");
	fscanf(fp, "%04d ", &tmpx);
	fscanf(fp, "%04d ", &tmpy);
	fscanf(fp, "%04d ", &_count);
	for (int i = 0; i < _count; i++)
	{
		int _posX;
		int _posY;
		int _sizeX;
		int _sizeY;
		int _nomalSize;
		int _state;
		
		fscanf(fp, "%04d ", &_posX);
		fscanf(fp, "%04d ", &_posY);
		fscanf(fp, "%03d ", &_sizeX);
		fscanf(fp, "%02d ", &_sizeY);
		fscanf(fp, "%02d ", &_nomalSize);
		fscanf(fp, "%02d ", &_state);
		Tile *tile = new Tile(_posX, _posY, _sizeX,_sizeY, _nomalSize, _state);
		tile->initTiles();
		tile->collider.type = box;
		tile->collider.rt.left = _posX;
		tile->collider.rt.right = _posX+_sizeX;
		tile->collider.rt.top = _posY;
		tile->collider.rt.bottom = _posY+_sizeY;
		tile->collider.center.x = tile->collider.rt.left + (tile->collider.rt.right - tile->collider.rt.left) / 2;
		tile->collider.center.y = tile->collider.rt.top + (tile->collider.rt.bottom - tile->collider.rt.top) / 2;
		tile->collider.radius = _nomalSize+1;
		mapTilesList.push_back(*tile);
		delete tile;
	}

	fclose(fp);
}

void Map::camera(float moving)
{
	scroll.x = moving;
}

/////////////////////////////////////////////////////

void Tile::initTiles()
{
	if(this->getState() == platformTile)
		bitmap.init("res/platform2.bmp");
	if (this->getState() == groundTile)
		bitmap.init("res/ground2.bmp");
}