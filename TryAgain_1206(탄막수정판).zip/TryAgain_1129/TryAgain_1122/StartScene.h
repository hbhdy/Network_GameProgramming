#pragma once
#include "resource.h"
#include "Scene.h"
#include "WaitScene.h"
#include "set.h"
#include "WrappedWnd.h"


class StartScene : public CScene
{
private:
	//�̹���
	CBitmap bitmap;

	//Ŭ���̾�Ʈ���콺��ǥ(���)
	POINT mPos;
	
public:
	

public:

	StartScene();
	~StartScene() {};

	void					create();

	void					initialize();

	void					update(float dt);
	void					render(HDC hdc, float dt);

	void					clear();

	void					destroy();

	void					FixClientCursor(POINT *p);

};

