#ifndef _SET_H_
#define _SET_H_

#pragma once
#include "GameFramework.h"
#include "SceneManager.h"
#include "WaitScene.h"
#include "StartScene.h"
#include "PrepareWnd.h"

static CGameFramework *g_framework;

#endif