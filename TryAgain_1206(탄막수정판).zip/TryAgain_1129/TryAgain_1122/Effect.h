#pragma once

#include "GameObject.h"
#include "Bitmap.h"

class ArrowEffect : public GameObject
{
private:
	HWND m_hWnd;

	//�߻� ��ġ
	Vector2D firstPos;
	//�̹���
	AniInfo aniInfo;
	Vector2D bitmapSize;
	Vector2D scroll;

	float aniTime;
	int animationNum;
	bool isOver;
public:
	ArrowEffect();
	ArrowEffect(Vector2D initPos);
	~ArrowEffect();
	void init();
	void Update(float dt);
	void Render(HDC hdc, float dt);
	void Delete();
	bool getIsOver(){ return isOver; };
	Vector2D getBitmapSize(){ bitmapSize.x = aniInfo.image.getBitmapInfo().bmWidth; bitmapSize.y = aniInfo.image.getBitmapInfo().bmHeight; return bitmapSize; };

	void camera(float moving);
	void setAniTime(float dt);
};

///////////////////////////////////////
class BulletEffect : public GameObject
{
private:
	HWND m_hWnd;

	//�߻� ��ġ
	Vector2D firstPos;
	//�̹���
	AniInfo aniInfo;
	Vector2D bitmapSize;
	Vector2D scroll;

	float aniTime;
	int animationNum;
	bool isOver;
public:
	BulletEffect();
	BulletEffect(Vector2D initPos);
	~BulletEffect();
	void init();
	void Update(float dt);
	void Render(HDC hdc, float dt);
	void Delete();
	bool getIsOver(){ return isOver; };
	Vector2D getBitmapSize(){ bitmapSize.x = aniInfo.image.getBitmapInfo().bmWidth; bitmapSize.y = aniInfo.image.getBitmapInfo().bmHeight; return bitmapSize; };

	void camera(float moving);
	void setAniTime(float dt);
};