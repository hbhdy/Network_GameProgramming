#pragma once

#include "WrappedWnd.h"

class CSceneManager;

//HWND g_hWnd;
class CGameFramework : public CWrappedWnd
{
private:
	DWORD prevFrameTime;

	CGameFramework( );
	~CGameFramework( );

public:

	static CGameFramework*	getGameFramework( );
	static LRESULT CALLBACK WndProc( HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam );

public:

	virtual void			ProcessingLoop( ) override;

	void					update( float dt );
	void					render( HDC hdc, float dt );

private:

	CSceneManager*			m_SceneManager;

public:

	CSceneManager*			getSceneManager( );

public:

	void					setFrameInterval( DWORD interval );
	DWORD					getFrameInterval( );

private:

	DWORD					m_FPS;

};
