
#pragma once
#include "GameScene.h"
#include "Scene.h"
#include "set.h"
#include <vector>
class WaitScene : public CScene
{
private:
	Player *player;
	Map *map;
	list<ArcherSkillOne> arrow;

	Player *otherPlayers[MAX_PLAYER];
	ArcherSkillOne otherArrow[MAX_PLAYER][MAX_ARROW_SIZE];

public:

	WaitScene();
	~WaitScene(){};

	void					create();

	void					initialize();

	void					update(float dt);
	void					render(HDC hdc, float dt);

	void					clear();

	void					destroy();

public:



};
