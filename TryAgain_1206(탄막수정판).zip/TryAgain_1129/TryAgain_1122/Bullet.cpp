#include "Bullet.h"
#define PI 3.14f

Bullet::Bullet()
{

}

Bullet::Bullet(Vector2D _pos, int _state)
{
	pos = _pos;
	scroll.Zero();
	state = _state;
	demage = BARRAGE_DAMAGE;
}

Bullet::~Bullet()
{
}

void Bullet::init()
{
}
void Bullet::init(CBitmap bm)
{
	bitmap.init("res/skill1.bmp");
	// �� state�� ���� ���� �ʱⰪ�� �ٸ��� �ش� 
	// ������ class�� �ϳ��� �⵵�� �� 
	if (state == spiralBullet) {

		angle = 5.f;
		angleRate = 0.15f;
		speed = 1.f;
		speedRate = 100.f;
	}
	if (state == directionalBullet200) {

		angle = 0.45f;
		angleRate = 0.f;
		speed = 200.f;
		speedRate = 50.0f;
	}
	if (state == directionalBullet160) {

		angle = -0.45f;
		angleRate = 0.f;
		speed = 200.f;
		speedRate = 100.0f;
	}
	if (state == rainBullet) {

		angle = 0.f;
		angleRate = 0.f;
		speed = 150.f;
		speedRate = 10.0f;
	}
	if (state == nwayBullet) {
		//angle = 0.35f;
		angleRate = 0.f;
		speed = 100.f;
		speedRate = 10.f;
	}

}

void Bullet::Update(float dt)
{
	// ������ ���� ������ ��ȯ
	float rad = angle*PI * 2;
	if (state == spiralBullet || state == directionalBullet200 || state == directionalBullet160) {
		locate = pos + scroll;
		//printf("%.2f\n", locate.x);
		pos.x += speed *cosf(rad) * dt;
		pos.y += speed*sinf(rad) * dt;
		// �ӵ��� ���ӵ� ����
		speed += speedRate* dt;
		// ������ ���ӵ� ����
		angle += angleRate* dt;
	}

	if (state == sinBullet) {
		float degree = (sinangle*num);
		locate = pos + scroll;
		pos.x += -speed* dt;
		pos.y += sinf(degree)*radian * dt;
		speed += speedRate* dt;
		angle += angleRate*dt;
		num++;
		if (num >= 360)
			num = 0;
	}
	if (state == rainBullet) {
		locate = pos + scroll;
		//printf("%.2f\n", locate.x);
		pos.x += 0.f;
		pos.y += speed * dt;
		// �ӵ��� ���ӵ� ����
		speed += speedRate* dt;
		// ������ ���ӵ� ����
		angle += angleRate* dt;
	}
	if (state == nwayBullet) {

		locate = pos + scroll;

		pos.x += speed *cosf(rad) * dt;
		pos.y += speed*sinf(rad) * dt;
		// �ӵ��� ���ӵ� ����
		speed += speedRate* dt;
		// ������ ���ӵ� ����
		angle += angleRate* dt;
	}

}

void Bullet::Render(HDC hdc, float dt)
{
	if (0 - 32 < (int)pos.x + (int)scroll.x  && WINDOW_WIDTH + 32 > (int)pos.x + (int)scroll.x &&
		0 < (int)pos.y  && WINDOW_HEIGHT - 50 > (int)pos.y )
		bitmap.drawBitmap(hdc, (int)pos.x + (int)scroll.x, (int)pos.y + (int)scroll.y, 0, 0);
	
}

void Bullet::Delete()
{

}

CollInfo Bullet::Collider()
{
	collider.obejctType = e_barrage;
	collider.center = pos;
	collider.rt.left = (LONG)pos.x;
	collider.rt.right = (LONG)pos.x + bitmap.getBitmapInfo().bmWidth;
	collider.rt.top = (LONG)pos.y;
	collider.rt.bottom = (LONG)pos.y + bitmap.getBitmapInfo().bmHeight;
	collider.center.x = collider.rt.left + (collider.rt.right - collider.rt.left) / 2;
	collider.center.y = collider.rt.top + (collider.rt.bottom - collider.rt.top) / 2;
	return collider;
}

void Bullet::camera(float moving)
{
	scroll.x = moving;
}