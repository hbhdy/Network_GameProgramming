#include "Effect.h"

ArrowEffect::ArrowEffect()
{
}
ArrowEffect::ArrowEffect(Vector2D initPos)
{
	firstPos = initPos;
	pos = initPos;
	animationNum = 0;
	isOver = false;
}
ArrowEffect::~ArrowEffect()
{
}

void ArrowEffect::init()
{
	aniInfo.aniNum = 5;
	aniInfo.image.init("res/arrow_effect.bmp");
}

void ArrowEffect::Update(float dt)
{
	if (!isOver)
	setAniTime(dt);
}

void ArrowEffect::Render(HDC hdc, float dt)
{
	aniInfo.image.drawBitmap(hdc, (int)pos.x + (int)scroll.x, (int)pos.y + (int)scroll.y,
		aniInfo.image.getBitmapInfo().bmWidth / (aniInfo.aniNum+1), aniInfo.image.getBitmapInfo().bmHeight, animationNum);
}

void ArrowEffect::Delete()
{
}

void ArrowEffect::camera(float moving)
{
	scroll.x = moving;
}

void ArrowEffect::setAniTime(float dt)
{
	aniTime += dt;
	if (aniTime > dt * 2) // 
	{
		animationNum++;
		if (animationNum > aniInfo.aniNum)
			isOver = true;
		aniTime = 0.0f;
	}
}


////////////////////bullet effect //////////////////////////////

BulletEffect::BulletEffect()
{
}
BulletEffect::BulletEffect(Vector2D initPos)
{
	firstPos = initPos;
	pos = initPos;
	animationNum = 0;
	isOver = false;
}
BulletEffect::~BulletEffect()
{
}

void BulletEffect::init()
{
	aniInfo.aniNum = 7;
	aniInfo.image.init("res/bullet_effect.bmp");
}

void BulletEffect::Update(float dt)
{
	if (!isOver)
	setAniTime(dt);
}

void BulletEffect::Render(HDC hdc, float dt)
{
	aniInfo.image.drawBitmap(hdc, (int)pos.x + (int)scroll.x, (int)pos.y + (int)scroll.y,
		aniInfo.image.getBitmapInfo().bmWidth / (aniInfo.aniNum + 1), aniInfo.image.getBitmapInfo().bmHeight, animationNum);
}

void BulletEffect::Delete()
{
}

void BulletEffect::camera(float moving)
{
	scroll.x = moving;
}

void BulletEffect::setAniTime(float dt)
{
	aniTime += dt;
	if (aniTime > dt * 2) // 10�����Ӵ� 1�� �ٲ�
	{
		animationNum++;
		if (animationNum > aniInfo.aniNum)
			isOver = true;
		aniTime = 0.0f;
	}
}