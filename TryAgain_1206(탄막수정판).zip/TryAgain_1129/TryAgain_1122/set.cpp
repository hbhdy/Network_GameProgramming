#include "set.h"

#pragma comment(linker , "/entry:WinMainCRTStartup /subsystem:console")
#pragma warning (disable:4996)

void settingWnd( CPrepareWnd& value )
{
	value.lpWindowName = "network_project";
}

void settingGame( )
{
	g_framework = CGameFramework::getGameFramework( );

	g_framework->getSceneManager()->registerScene(new StartScene);
	g_framework->getSceneManager()->reservedScene();
}