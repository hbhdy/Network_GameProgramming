#include "WaitScene.h"
#include "Bitmap.h"

static int x = 0, y = 0;
extern Network *network;

WaitScene::WaitScene()
{
}

void WaitScene::create()
{
	Vector2D initPlayerPos(200, 200);
	Vector2D dir(1, 0);
	player = new Player(initPlayerPos, dir, ARROW_PLAYER_SPEED , false);
	map = new Map(waitscene);

	for (int i = 0; i < MAX_PLAYER; i++)
		otherPlayers[i] = new Player(initPlayerPos, dir, ARROW_PLAYER_SPEED, true);
}

void WaitScene::initialize()
{
	map->init();
	player->init();

	for (int i = 0; i < MAX_PLAYER; i++)
		otherPlayers[i]->init();
	for (int i = 0; i < MAX_CLIENT; i++)
		for (int j = 0; j < MAX_ARROW_SIZE; j++){
			otherArrow[i][j].init();
			otherArrow[i][j].initPos(true);
		}

	player->setCurrentMapSize(map->getBitMapSize());
}

void WaitScene::update(float dt)
{
	//coll 
	Coll_Player_Tile(player, map, dt);

	//event
	if (player->Fire()){
		ArcherSkillOne *sk = new ArcherSkillOne(player->getWeaponPos(), player->getWeaponDir());
		sk->init();
		arrow.push_back(*sk);
		delete sk;
	}

	//player camera 
	float tmp = player->PlayerEvent(dt);
	map->camera(tmp);

	//object update
	player->Update(dt);
	map->Update(dt);

	if (!arrow.empty())
		for (auto i = arrow.begin(); i != arrow.end();){
			(*i).camera(tmp);
			(*i).Update(dt);
			//���� - ��ų
			if ((*i).distFirstPos() > REMOVE_SKILL_DIST)
				arrow.erase(i++);
			else
				i++;
		}

	//������
	network->tbServerInfo->scene = wait;
	if (GetAsyncKeyState('R') && 0x8000)
	{
		if (network->tbServerInfo->myClientValue == 0){
			network->tbServerInfo->scene = game;
		}
	}

	//�÷��̾� ����
	network->tbServerInfo->player[network->tbServerInfo->myClientValue].pos = player->pos;
	network->tbServerInfo->player[network->tbServerInfo->myClientValue].arm.pos = player->getArm()->pos;
	network->tbServerInfo->player[network->tbServerInfo->myClientValue].arm.angle = player->getArm()->angle;
	//ȭ�� ����
	network->tbServerInfo->arrowSize[network->tbServerInfo->myClientValue] = arrow.size();
	int arrowCount=0;
	for (auto i = arrow.begin(); i != arrow.end(); i++){
		network->tbServerInfo->arrow[network->tbServerInfo->myClientValue][arrowCount].pos = (*i).pos;
		network->tbServerInfo->arrow[network->tbServerInfo->myClientValue][arrowCount].angle = (*i).angle;
		arrowCount++;
	}

	if(network->sendToServer(network->getSocket(), *network->tbServerInfo, 0)); //�����ͺ�����
	network->recvFromServer(network->getSocket(), 0); //�ޱ�
	//������ó��

	//update network objects

	for (int i = 0; i < network->tbServerInfo->playerSize; i++){
		//skip to My client player infomation 
		otherPlayers[i]->pos = network->tbServerInfo->player[i].pos;
		otherPlayers[i]->camera(tmp);
		//arm(weapon) network
		otherPlayers[i]->getArm()->angle = network->tbServerInfo->player[i].arm.angle;
		otherPlayers[i]->getArm()->ArrowPlayer(otherPlayers[i]->locate, otherPlayers[i]->pos);
		otherPlayers[i]->getArm()->camera(tmp);
	}


	for (int cl = 0; cl < network->tbServerInfo->nowClient; cl++){ //Ŭ���̾�Ʈ����
		for (int i = 0; i < network->tbServerInfo->arrowSize[cl]; i++){ //Ŭ���ַο찹��
			otherArrow[cl][i].initPos(true);
			otherArrow[cl][i].pos = network->tbServerInfo->arrow[cl][i].pos;
			otherArrow[cl][i].angle = network->tbServerInfo->arrow[cl][i].angle;
			otherArrow[cl][i].camera(tmp);
		}
	}

	//������ ������
	if (network->tbServerInfo->scene == game){
		g_framework = CGameFramework::getGameFramework();
		g_framework->getSceneManager()->registerScene(new GameScene);
		g_framework->getSceneManager()->reservedScene();
	}
	
}

void WaitScene::render(HDC hdc, float dt)
{
	map->Render(hdc, dt);


	for (int i = 0; i < network->tbServerInfo->playerSize; i++){
		otherPlayers[i]->Render(hdc, dt);
	}

	//player�� ī�޶󰡵Ǳ� ���� ������ �ڵ鰪
	player->setWindowHWND(getWindowHWND());
	//player->Render(hdc, dt);

	/*if (!arrow.empty())
		for (auto i = arrow.begin(); i != arrow.end(); i++)
			(*i).Render(hdc, dt);*/

	//ȭ��
	for (int cl = 0; cl < network->tbServerInfo->nowClient; cl++){
		for (int i = 0; i < network->tbServerInfo->arrowSize[cl]; i++){
			otherArrow[cl][i].Render(hdc, dt);
		}
	}
}

void WaitScene::clear()
{
	
}

void WaitScene::destroy()
{
	player->Delete();
	map->Delete(); 
	if (1 < network->tbServerInfo->nowClient)
	for (auto i = arrow.begin(); i != arrow.end();)
		arrow.erase(i++);
	for (int i = 0; i < MAX_PLAYER; i++)
		otherPlayers[i]->Delete();

	for (int i = 0; i < MAX_PLAYER; i++)
		delete otherPlayers[i];
	delete player;
	delete map;

}