#pragma once
#include "Map.h"
#include "Player.h"
#include <list>

using namespace std;

bool Coll_Player_Tile(Player *player, Map *map, float dt)
{
	CollInfo playerCol = player->Collider();
	//list<Tile> mapList = map->ColliderList();

	for (auto i = map->mapTilesList.begin(); i != map->mapTilesList.end(); i++) {

		//���������� üũ
		if (player->getState() == r_fall || player->getState() == l_fall){
			if (player->pos.x + player->getSize().x / 2 > (*i).collider.rt.left &&
				player->pos.x + player->getSize().x / 2 < (*i).collider.rt.right &&
				player->pos.y + player->getSize().y - 5 > (*i).collider.rt.top &&
				player->pos.y + player->getSize().y - 5 < (*i).collider.rt.bottom){
				//�浹ó��
				player->collCorrection((int)(*i).collider.rt.top + 5);
				return true;
			}
		}
		//�� �߹ؿ� Ÿ���� �ִ��� üũ, ������ �߷��ۿ�
		//�÷��̾��� �� �� ��� ������ Ÿ�ϰ� �浹���
		if (player->getState() != r_fall || player->getState() != l_fall){
			if (player->pos.x + player->getSize().x / 2 > (*i).collider.rt.left &&
				player->pos.x + player->getSize().x / 2 < (*i).collider.rt.right &&
				player->pos.y + player->getSize().y - 5 + 1 > (*i).collider.rt.top &&
				player->pos.y + player->getSize().y - 5 + 1 < (*i).collider.rt.bottom){

				//printf("%.2f %.2f  %d\n", player->pos.x + player->getSize().x / 2, player->pos.y + player->getSize().y + 1, (*i).collider.rt.top);
				return true;
			}
		}
	}
	player->setIsGround(false);
	player->setState(r_fall);

	return false;
}
