#include "Network_Server.h"
int test = 0;
bool client[MAX_CLIENT] = { false, }; //Ŭ���̾�Ʈ ��
ClientInfo totalServerInfo; //�Ѱ��� ������
HANDLE hWaitEvent;
ClientInfo *clientInfo[MAX_CLIENT]; //���� ������
int g_Client = 0; //�� Ŭ���̾�Ʈ ����
float DeltaTime = 0;

bool isGameScene = false;

//�������� ������ ����
BossInfo bossInfo;
PattenInfo pattenInfo[MAX_PATTEN][MAX_BULLET];

Patten *patten[MAX_PATTEN];//, *patten2, *patten3, *patten4, *patten5, *patten6;
list<Bullet> bl[MAX_PATTEN];

bool g_ClientRecv[MAX_CLIENT] = { false, };
bool g_ClientSend[MAX_CLIENT] = { false, };
int g_RecvCount = 0;
int opt = 1;

DWORD WINAPI ProcessTime(LPVOID arg) {
	DWORD prevFrameTime = GetTickCount();
	float frameDelta;
	while (1)
	{
		frameDelta = (GetTickCount() - prevFrameTime)*0.001f;
		if (frameDelta >= (float)1 / 60)
		{
			DeltaTime = frameDelta;
			
			if (isGameScene){
				for (int i = 0; i < MAX_PATTEN; i++){
					patten[i]->Update(DeltaTime);
				}
			}

			prevFrameTime = GetTickCount();
		}
	}
}


DWORD WINAPI ProcessClient(LPVOID arg) {
	SetEvent(hWaitEvent);

	SOCKET client_sock = (SOCKET)arg;
	SOCKADDR_IN clientaddr;

	int addrlen;
	int retval;
	int len = 0;
	
	DWORD prevFrameTime = GetTickCount();
	float frameDelta;
	
	int nowClient = 0; //����Ŭ���̾�Ʈ ��ȣ
	bool isRecv = false;
	char buf[BUFSIZE + 1];
	char *tempBuffer = (char*)malloc(sizeof(char)*BUFSIZE);
	// Ŭ���̾�Ʈ ���� ���
	addrlen = sizeof(clientaddr);
	getpeername(client_sock, (SOCKADDR *)&clientaddr, &addrlen);

	//ID �ο�
	for (int i = 0; i < MAX_CLIENT; ++i){
		if (client[i] == false){
			client[i] = true;
			nowClient = i; //Ŭ���̾�Ʈ id
			break;
		}
	}

	//������ ����
	while (1) {
		frameDelta = (GetTickCount() - prevFrameTime)*0.001f;
		if (frameDelta >= (float)1 / 60)
		{
			DeltaTime = frameDelta;

			int g_ClientTmp = g_Client;
			//�������� ������ �ޱ�
			int GetSize;

			retval = recv(client_sock, (char *)&len, sizeof(int), 0);
			if (retval == SOCKET_ERROR) {
				err_display("recv()");
				break;
			}
			else if (retval == 0)break;
			tempBuffer = (char*)realloc(tempBuffer, sizeof(char)*len+1);
			GetSize = recvn(client_sock, tempBuffer, len, 0);
			if (GetSize == SOCKET_ERROR || GetSize== 0)continue;
			tempBuffer[GetSize] = '\0';
			clientInfo[nowClient] = (ClientInfo*)tempBuffer;
			// ������ �ޱ�(���� ����)
			if (retval == SOCKET_ERROR) {
				err_display("recv()");
				break;
			}
			else if (retval == 0)
				break;

		//�ް� �ʱ�ȭ�� �ʿ��� ������
			for (int j = 0; j < MAX_ARROW_SIZE; j++)
				totalServerInfo.arrow[nowClient][j].isColl = false;

		//���� ������ ó��
			WaitForSingleObject(hWaitEvent, INFINITE);

			totalServerInfo.myClientValue = nowClient;//�����ѹ�
			totalServerInfo.maxClient = MAX_CLIENT;
			totalServerInfo.nowClient = g_Client;

			//scene
			if (clientInfo[0]->scene == game){
				totalServerInfo.scene = game;
				isGameScene = true;
			}
			//player
			if (clientInfo[nowClient]->scene != start){
				
				if (clientInfo[nowClient]->player[nowClient].pos.x > 0 && clientInfo[nowClient]->player[nowClient].pos.x < 3000){//��ȿ�Ѱ��̸�
					totalServerInfo.playerSize = totalServerInfo.nowClient;
					totalServerInfo.player[nowClient].pos = clientInfo[nowClient]->player[nowClient].pos;
					totalServerInfo.player[nowClient].arm.pos = clientInfo[nowClient]->player[nowClient].arm.pos;
					totalServerInfo.player[nowClient].arm.angle = clientInfo[nowClient]->player[nowClient].arm.angle;
				}
			}

			//boss
			if (clientInfo[nowClient]->scene == game){
				totalServerInfo.boss.hp = bossInfo.hp;
				totalServerInfo.boss.pos.x = bossInfo.pos.x;
				totalServerInfo.boss.pos.y = bossInfo.pos.y;
				totalServerInfo.boss.bitmapSize = clientInfo[nowClient]->boss.bitmapSize;
				bossInfo.bitmapSize = totalServerInfo.boss.bitmapSize;
			}

			//arrow
			if (clientInfo[nowClient]->arrowSize[nowClient] >= 0 && clientInfo[nowClient]->arrowSize[nowClient] < MAX_ARROW_SIZE){
				totalServerInfo.arrowSize[nowClient] = clientInfo[nowClient]->arrowSize[nowClient];
				
				for (int j = 0; j < clientInfo[nowClient]->arrowSize[nowClient]; j++){
					totalServerInfo.arrow[nowClient][j].bitmapSize = clientInfo[nowClient]->arrow[nowClient][j].bitmapSize;
					totalServerInfo.arrow[nowClient][j].angle = clientInfo[nowClient]->arrow[nowClient][j].angle;
					totalServerInfo.arrow[nowClient][j].pos = clientInfo[nowClient]->arrow[nowClient][j].pos;
					
					//���� ȭ�� �浹
					if (CollObejct(&bossInfo, &totalServerInfo.arrow[nowClient][j], BOSS_COLL_DISTANCE)){
						bossInfo.hp -= clientInfo[nowClient]->arrow[nowClient][j].demage;
						totalServerInfo.arrow[nowClient][j].isColl = true;
						printf("%d dtCenter(%.1f %.1f)\tsrcCenter(%.1f %.1f)\n", bossInfo.hp, bossInfo.Collider().center.x, bossInfo.Collider().center.y,
							clientInfo[nowClient]->arrow[nowClient][j].Collider().center.x, clientInfo[nowClient]->arrow[nowClient][j].Collider().center.y);
					}
				}
			}
			else{
				for (int j = 0; j < totalServerInfo.arrowSize[nowClient]; j++) {
					totalServerInfo.arrow[nowClient][j].pos.x = -100;
				}
			}

			//patten
			//�浹���� �ʱ�ȭ
			int collNum[MAX_PATTEN];
			for (int i = 0; i < MAX_PATTEN; i++)
				for (int j = 0; j < MAX_BULLET; j++)
					totalServerInfo.patten[i][j].isColl = false;
			if (clientInfo[nowClient]->scene == game){
				for (int i = 0; i < MAX_PATTEN; i++){
					bl[i] = patten[i]->getBullet();
					//�Ѿ˰� �浹�� �÷��̾� ����
					patten[i]->setPlayerPointer(&clientInfo[nowClient]->player[nowClient]);
					collNum[i] = patten[i]->Coll(DeltaTime);
				}
				//�÷��̾�� �浹
				for (int i = 0; i < MAX_PATTEN; i++){
					if (collNum[i] != -1){ //�浹��
						totalServerInfo.player[nowClient].hp -= patten[i]->demage;
						totalServerInfo.patten[i][collNum[i]].isColl = true;
					}
				}
			
				for (int z = 0; z < MAX_PATTEN; z++){
					int pattenSize = 0;
					for (auto i = bl[z].begin(); i != bl[z].end(); i++){
						totalServerInfo.patten[z][pattenSize].pos = (*i).pos;
						pattenSize++;
					}
					totalServerInfo.pattenSize[z] = pattenSize;
				}
			}

			//�������� ������ �ֱ�
			int retval;
			// ������ ������
			int len = sizeof(totalServerInfo);
			retval = send(client_sock, (char *)&len, sizeof(int), 0);
			if (retval == SOCKET_ERROR) {
				err_display("send()");
				exit(1);
			}
			// ������ ������( ����ü �����͸� ������. )
			retval = send(client_sock, (char*)&totalServerInfo, sizeof(totalServerInfo), 0);
			if (retval == SOCKET_ERROR) {
				err_display("send()");
				exit(1);
			}
			SetEvent(hWaitEvent);

			//}
			//������ó��
			prevFrameTime = GetTickCount();
		}
			
	}
	free(tempBuffer);
	closesocket(client_sock);
	client[g_Client] = false;
	return 0;
}

int main(int argc, char *argv[]) {
	int retval;

	hWaitEvent = CreateEvent(NULL, FALSE, TRUE, NULL);
	if (hWaitEvent == NULL) return 1;
	// ���� �ʱ�ȭ
	WSADATA wsa;
	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
		return 1;

	// socket()
	SOCKET listen_sock = socket(AF_INET, SOCK_STREAM, 0);
	if (listen_sock == INVALID_SOCKET) err_quit("socket()");

	setsockopt(listen_sock, IPPROTO_TCP, TCP_NODELAY, (const char*)&opt, sizeof(opt));

	// bind()
	SOCKADDR_IN serveraddr;
	ZeroMemory(&serveraddr, sizeof(serveraddr));
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
	serveraddr.sin_port = htons(SERVERPORT);
	retval = bind(listen_sock, (SOCKADDR *)&serveraddr, sizeof(serveraddr));
	
	if (retval == SOCKET_ERROR) err_quit("bind()");

	// listen()
	retval = listen(listen_sock, SOMAXCONN);
	if (retval == SOCKET_ERROR) err_quit("listen()");

	// ������ ��ſ� ����� ����
	SOCKET client_sock;
	SOCKADDR_IN clientaddr;
	int addrlen;
	HANDLE hThread , hTimeThread;

	printf("Server is Ready..!\n\n");

	//������ ���� �ʱ�ȭ
	bossInfo.hp = 300;
	bossInfo.pos.x = 1850;
	bossInfo.pos.y = 200;

	Vector2D initPat1Pos(1850, 500);
	Vector2D initPat4Pos(1850, 300); // sinBullet
	Vector2D initPat5Pos(1850, 300); // nwayBullet
	Vector2D initPat6Pos;
	patten[0] = new Patten(initPat1Pos, initPat1Pos, spiralBullet, 7);
	patten[0]->init();
	patten[1] = new Patten(initPat1Pos, initPat1Pos, directionalBullet200, 20);
	patten[1]->init();
	patten[2] = new Patten(initPat1Pos, initPat1Pos, directionalBullet160, 20);
	patten[2]->init();
	patten[3] = new Patten(initPat4Pos, initPat4Pos, sinBullet, 25);
	patten[3]->init();
	patten[4] = new Patten(initPat5Pos, initPat5Pos, nwayBullet, 20);
	patten[4]->init();
	patten[5] = new Patten(initPat6Pos, initPat6Pos, rainBullet, 10);
	patten[5]->init();

	int a = 0;
	hTimeThread = CreateThread(NULL, 0, ProcessTime, (LPVOID)a, 0, NULL);
	if (hTimeThread == NULL) {
		closesocket(client_sock);
	}
	else {
		CloseHandle(hTimeThread);
	}

	while (1) {
		// accept()
		addrlen = sizeof(clientaddr);
		client_sock = accept(listen_sock, (SOCKADDR *)&clientaddr, &addrlen);
		if (client_sock == INVALID_SOCKET) {
			err_display("accept()");
			break;
		}
		
		if (g_Client >= MAX_CLIENT) break;
		//clientInfo[g_Client]->myClientValue = g_Client;
		g_Client++;
		// ������ Ŭ���̾�Ʈ ���� ���
		printf("\nŬ���̾�Ʈ ����: IP �ּ�=%s, ��Ʈ ��ȣ=%d\n", inet_ntoa(clientaddr.sin_addr), ntohs(clientaddr.sin_port));
		// ������ ����
		hThread = CreateThread(NULL, 0, ProcessClient, (LPVOID)client_sock, 0, NULL);
		
		if (hTimeThread == NULL) {
			closesocket(client_sock);
		}
		else {
			CloseHandle(hThread);
		}
		
	}
	for (int i = 0; i < MAX_PATTEN; i++)
	delete patten[i];
	// �̺�Ʈ ����
	CloseHandle(hWaitEvent);
	// closesocket()
	closesocket(listen_sock);

	// ���� ����
	WSACleanup();
	return 0;
}