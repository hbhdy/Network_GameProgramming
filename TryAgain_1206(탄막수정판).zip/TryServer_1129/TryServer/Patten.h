#ifndef _PATTEN_H_
#define _PATTEN_H_

#pragma once
#include "GameObject.h"
#include "Bitmap.h"
#include "Bullet.h"

#include <list>

using namespace std;

class Patten : public GameObject
{
private:
	//�̹���
	CBitmap bitmap;
	list<Bullet> bullets;

	int state;
	int frameDelay;
	int hp;
	Vector2D scroll;

	float delayTime;
	bool isCreateBullet;

	PlayerInfo *pPlayer;
	Bullet *bl;

	// �߰�
	//float angleSave;

public:
	int demage;

public:
	Patten();
	Patten(Vector2D initPos, Vector2D initDir,int state, int frameDelay);
	~Patten();
	void init();
	void Update(float dt);
	void Render(HDC hdc, float dt);
	void Delete();
	void camera(float moving);
	void setBulletTime(float dt);
	void setPlayerPointer(PlayerInfo *p){pPlayer = p;}
	list<Bullet> getBullet(){return bullets;}

	int Coll(float dt);
};

#endif;