#define SERVERPORT 9000
#define BUFSIZE    1024
#define MAX_CLIENT 4

//network
#define MAX_ARROW_SIZE 30
#define BOSS_COLL_DISTANCE 150
#define ARROW_DAMAGE 5

#define MAX_PATTEN 6
#define MAX_BULLET 200

#define GUARDIAN 0

#define BARRAGE_DAMAGE 5

#define PLAYER_COLL_DISTANCE 20
#define REMOVE_SKILL_DIST 1200