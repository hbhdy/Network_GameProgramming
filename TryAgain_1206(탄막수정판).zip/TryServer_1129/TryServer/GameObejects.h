#pragma once
#include <list>
#include "Vector2D.h"
#include "Bitmap.h"

enum {
	start = 0,
	wait,
	game
};

//Collider�Լ��� ���� ��ü
template<typename Dest, typename Source>
bool CollObejct(Dest *dest, Source *src, int dist)
{
	//�浹�˻�
	if (dest->Collider().center.Distance(src->Collider().center) < dist){
		return true;
	}
	return false;
}
