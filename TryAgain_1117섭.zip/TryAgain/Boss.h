#pragma once
#include "GameObject.h"
#include "Bitmap.h"

class Boss : public GameObject
{
private:
	//�̹���
	CBitmap bitmap;

	int state;
	int hp;
	
public:
	Boss();
	Boss(Vector2D initPos, Vector2D initDir);
	~Boss();
	void init();
	void Update(float dt);
	void Render(HDC hdc, float dt);
	void Delete();
};