#include "Player.h"
#include "WrappedWnd.h"

Player::Player()
{
}
Player::Player(Vector2D initPos, Vector2D initDir,float speed)
{
	pos = initPos;
	locate = initPos;
	velocity = initDir;
	this->speed = speed;
}
Player::~Player()
{
}

void Player::init()
{
	//player init
	bitmap.init("res/Player.bmp");
	this->fGravityreiteration = ARROW_PLAYER_JUMPPOWER;
	state = fall;
	isGround = false;

	//arm init
	Vector2D armRotate(0,0);
	arm = new Arm(locate, armRotate);
	arm->init();


	skill = new Skill(locate, armRotate);
	skill->init();
}


void Player::Update(float dt)
{
	//player

	if (this->state == jump || this->state == fall)
		Jump(dt);




	

	//arm updates
	arm->ArrowPlayer(locate);
	arm->Update(dt);

	skill->SkillPlayer(locate);
	skill->Update(dt);
}


void Player::Render(HDC hdc, float dt)
{
	//printf("state = %d \n",state);

	
	bitmap.drawBitmap(hdc,locate.x,locate.y,0,0);

	//SetWindowPos();

	arm->Render(hdc,dt);


	skill->Render(hdc, dt);
}


void Player::Delete()
{

}

float Player::PlayerEvent(float dt)
{
	float scroll=0;

	//Ŀ�� ��ǥ
	GetCursorPos(&mousePoint);
	ScreenToClient(m_hWnd, (LPPOINT)&mousePoint);
	//printf("%.2f %.2f \t %.2f %.2f\n", pos.x, pos.x , locate.x , locate.y);
	//printf("%d %d\n", mousePoint.x, mousePoint.y);
	if ( GetAsyncKeyState( VK_RIGHT ) & 0x8000 )
	{
		//�ǳ� ��
		if (pos.x >= curMapSize.x - WINDOW_WIDTH / 2){
			this->locate.x += speed * dt;
			this->pos.x = curMapSize.x + locate.x - WINDOW_WIDTH;
		}
		//ó�� ��
		else if (locate.x < WINDOW_WIDTH / 2){
			this->locate.x += speed * dt;
			this->pos.x = locate.x;
		}
		//��ũ���ʿ�
		else if (locate.x >= WINDOW_WIDTH / 2)	{
			this->locate.x = WINDOW_WIDTH / 2;
			this->pos.x += speed * dt;
			//�ʽ�ũ�Ѱ�����
			
		}
		
	}
	if ( GetAsyncKeyState( VK_LEFT ) & 0x8000 )
	{
		//�ǿ���
		if (pos.x <= WINDOW_WIDTH / 2){
			scroll += pos.x - locate.x;
			this->locate.x -= speed * dt;
			this->pos.x = locate.x;
		}
		//������
		else if (locate.x > WINDOW_WIDTH / 2){
			
			this->locate.x -= speed * dt;
			this->pos.x = curMapSize.x + locate.x - WINDOW_WIDTH;
		}
		else if (locate.x >= WINDOW_WIDTH / 2){
			this->locate.x = WINDOW_WIDTH / 2;
			this->pos.x -= speed * dt;
			//�ʽ�ũ�Ѱ�����
		}
	}
	if ( GetAsyncKeyState( VK_UP ) & 0x8000 )
	{
		if( this->isGround )
			this->state = jump;
	}

	scroll = locate.x - pos.x;
	return scroll;
}

void Player::Jump(float dt)
{
	this->isGround = false;
	
	//gravity effect
	if( !this->isGround ){
		fGravityreiteration += GRAVITY * dt;
	}
	//jump
	this->locate.y += fGravityreiteration;

	//state check
	(fGravityreiteration >= 0)? this->state = fall : this->state = jump;

	//ground check (coll)
	if( this->locate.y >= 600 ){
		this->locate.y = 600;
		fGravityreiteration = 0.0f;
		this->isGround = true;
	}
	else{
		this->isGround = false;
	}

	if( isGround ){
		this->state = r_idle;
		this->fGravityreiteration = ARROW_PLAYER_JUMPPOWER;
	}
}


void Player::FixClientCursor(POINT *p)
{
	p->x -= STARTWINDOW_X;
	p->y -= STARTWINDOW_Y;
}
