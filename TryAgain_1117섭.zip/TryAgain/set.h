#pragma once
#include "GameFramework.h"
#include "SceneManager.h"
#include "HelloWord.h"
#include "PrepareWnd.h"

static CGameFramework *g_framework;