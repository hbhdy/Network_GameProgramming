#include "SceneManager.h"
#include "Scene.h"

using namespace std;

CSceneManager::CSceneManager() : m_CurrentScene(nullptr), m_ReservedScene(nullptr)
{
}

CSceneManager::~CSceneManager()
{
	while (!m_SceneContainer.empty())
	{
		m_SceneContainer.top()->destroy();
		delete m_SceneContainer.top();
		m_SceneContainer.pop();
	}
}

void CSceneManager::registerScene(CScene* scene)
{
	if (scene == nullptr)
		return;

	scene->create();
	m_SceneContainer.push(scene);
}

void CSceneManager::reservedScene()
{
	m_ReservedScene = m_SceneContainer.top();
}

void CSceneManager::popScene()
{
	m_SceneContainer.top()->destroy();
	delete m_SceneContainer.top();
	m_SceneContainer.pop();
	m_CurrentScene = m_SceneContainer.top();
}

void CSceneManager::update(float dt)
{
	if (m_ReservedScene != nullptr)
	{
		if (m_CurrentScene != nullptr)
			m_CurrentScene->clear();

		m_ReservedScene->initialize();
		m_CurrentScene = m_ReservedScene;

		m_ReservedScene = nullptr;
	}

	if (m_CurrentScene != nullptr)
		m_CurrentScene->update(dt);
}

void CSceneManager::render(HDC hdc, float dt)
{
	if (m_CurrentScene != nullptr){
		m_CurrentScene->setWindowHWND(m_hWnd);
		m_CurrentScene->render(hdc, dt);
	}
}
