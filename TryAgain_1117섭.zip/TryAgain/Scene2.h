#pragma once
#include "Scene.h"
#include "set.h"

class Scene2 : public CScene
{
public:

	Scene2();
	~Scene2(){};

	void					create();

	void					initialize();

	void					update(float dt);
	void					render(HDC hdc, float dt);

	void					clear();

	void					destroy();

public:



};

