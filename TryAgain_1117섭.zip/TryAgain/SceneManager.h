#pragma once

#include <Windows.h>
#include <string>
#include <stack>

class CScene;

using namespace std;
class CSceneManager
{
protected:
	HWND m_hWnd;
public:

	CSceneManager();
	~CSceneManager();

public:

	void					registerScene(CScene* scene);
	void					reservedScene();
	void					popScene();
	void					setWindowHWND(HWND hWnd){ m_hWnd = hWnd; };
public:

	void					update(float dt);
	void					render(HDC hdc, float dt);

private:

	stack<CScene*>	m_SceneContainer;

	CScene*					m_ReservedScene;
	CScene*					m_CurrentScene;

};
