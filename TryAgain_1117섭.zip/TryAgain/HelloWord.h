#pragma once
#include "Scene.h"
#include "Scene2.h"
#include "set.h"
#include <time.h>

class HelloWord : public CScene
{
private:
	Player *player;
	Map *map;

	Boss *boss;

	//SkillOne *skillone;

	// ȸ�� ź��
	vector<Spiral> sbullet;
	Spiral *spiral;
	// 200�� ���� ź��
	vector<Directional> dbullet200;
	Directional *directional200;
	// 160�� ���� ź��
	vector<Directional> dbullet160;
	Directional *directional160;
	// �㸮���� ź��
	vector<Hurricane> hbullet;
	Hurricane *hurricane;
	// �ʻ�� ź��
	vector<Power> pbullet;
	Power *power;

public:

	HelloWord( );
	~HelloWord( ){};

	void					create( );

	void					initialize( );

	void					update( float dt );
	void					render( HDC hdc, float dt );


	void					clear( );

	void					destroy( );

public:



};

