#include "PrepareWnd.h"
#include "GameFramework.h"
#include "Defines.h"

CPrepareWnd::CPrepareWnd()
{
	cbSize = sizeof(WNDCLASSEX);
	style = CS_HREDRAW | CS_VREDRAW;
	lpfnWndProc = nullptr;
	cbClsExtra = 0;
	cbWndExtra = 0;
	hIcon = nullptr;
	hCursor = LoadCursor(nullptr, IDC_ARROW);
	hbrBackground = (HBRUSH)(1 + 1);
	lpszClassName = "winclass";
	lpfnWndProc = CGameFramework::WndProc;

	lpWindowName = "test";
	dwStyle = WS_OVERLAPPEDWINDOW;
	X = STARTWINDOW_X;
	Y = STARTWINDOW_Y;
	nWidth = WINDOW_WIDTH;
	nHeight = WINDOW_HEIGHT;
	hWndParent = nullptr;
	hMenu = nullptr;
	lpParam = nullptr;

	nCmdShow = SW_SHOW;
}
