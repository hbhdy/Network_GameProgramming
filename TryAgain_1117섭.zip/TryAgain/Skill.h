#pragma once
#include "GameObject.h"
#include "Bitmap.h"

class Skill : public GameObject
{
private:

	//�̹���
	CBitmap bitmap;
	float angle;


	int state;
	bool isHit;
	Vector2D start;
	POINT Route;

public:

	Skill();
	Skill(Vector2D initPos, Vector2D initDir);
	~Skill();
	void init();
	void Update(float dt);
	void Render(HDC hdc, float dt);
	void Delete();
	void SkillPlayer(Vector2D playerPos) { playerPos.x -= 15;  locate = playerPos; };

};

class SkillOne : public Skill 
{
private:
	HWND m_hWnd;

	//�̹���
	CBitmap bitmap;
	Vector2D startPos;
	POINT mousePos;
	Vector2D movePos;

public:
	SkillOne();
	~SkillOne();
	void init();
	void Update(float dt);
	void Render(HDC hdc, float dt);
	void Delete();
};