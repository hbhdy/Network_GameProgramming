#include "Skill.h"

Skill::Skill()
{
}
Skill::Skill(Vector2D initPos, Vector2D initDir)
{
	locate = initPos;
	velocity = initDir;
	angle = 0;
}

Skill::~Skill()
{
	
}

void Skill::init()
{
	bitmap.init("res/Arrow2.bmp");
}

void Skill::Update(float dt)
{
	angle += 0.1;
}


void Skill::Render(HDC hdc, float dt)
{
	bitmap.drawBitmapRotate(hdc, locate.x, locate.y, 0, 0, 0, angle);
}


void Skill::Delete()
{

}

//-------------------------------------------------------------

//SkillOne::SkillOne()
//{
//}
//SkillOne::~SkillOne()
//{
//
//}
//
//void SkillOne::init()
//{
//	bitmap.init("res/Arrow2.bmp");
//	startPos.x = locate.x;
//	startPos.y = locate.y;
//	movePos.x = abs(mousePos.x - startPos.x)/100;
//	movePos.y = abs(mousePos.y - startPos.y)/100;
//	printf(" ���콺 ��ǥ �� %d %d \n ", startPos.x, startPos.y);
//}
//
//void SkillOne::Update(float dt)
//{
//	startPos.x += movePos.x;
//	startPos.y += movePos.y;
//	GetCursorPos(&mousePos);
//	ScreenToClient(m_hWnd, (LPPOINT)&mousePos);
//	//printf(" ���콺 ��ǥ �� %d %d \n ", mousePos.x, mousePos.y);
//	//printf(" ���콺 ��ǥ �� %d %d \n ", startPos.x, startPos.y);
//	
//}
//
//void SkillOne::Render(HDC hdc, float dt)
//{
//	bitmap.drawBitmap(hdc, startPos.x, startPos.y, 0, 0);
//}
//
//
//void SkillOne::Delete()
//{
//
//}