#include "Scene2.h"
#include "Bitmap.h"

static int x = 0, y = 0;

Scene2::Scene2()
{
}

void Scene2::create()
{
}

void Scene2::initialize()
{
}

void Scene2::update(float dt)
{
	if (GetAsyncKeyState(VK_RETURN) && 0x8000)
	{
		g_framework = CGameFramework::getGameFramework();
		g_framework->getSceneManager()->popScene();
	}
}

void Scene2::render(HDC hdc, float dt)
{
}

void Scene2::clear()
{
}

void Scene2::destroy()
{
}